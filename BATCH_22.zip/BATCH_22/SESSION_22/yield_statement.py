def compute(N): 
    for i in range(N): 
        yield i**2 

G = compute(8) 
print(f'type(G):{type(G)}')

while True: 
    try: 
        n = G.__next__() 
        print(n) 
    except StopIteration: 
        break 