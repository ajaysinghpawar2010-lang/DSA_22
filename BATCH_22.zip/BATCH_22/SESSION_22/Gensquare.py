"""
@goal: Implement Gensquare class such that 

for x in Gensquare(N): 
    print(x) 

will print squares of all numbers 0 to N-1, 
one number per iteration. 
"""

class Gensquare_iterator: 
    def __init__(self, G): 
        self.G = G 

    def __next__(self): 
        return self.G.__next__()

class Gensquare: 
    def __init__(self, N: int): 
        if type(N) != int: 
            raise TypeError 
        self.N = N 

    def __iter__(self): 
        def get_generator(N:int): 
            for i in range(N): 
                yield i ** 2 
        return Gensquare_iterator(get_generator(self.N))


def main(): 
    G = Gensquare(8)

    print("Using for loop")
    for x in G: 
        print(x) 

    print("using while loop")
    I = G.__iter__() # Gensquare_iterator 
    while True: 
        try: 
            x = I.__next__() 
            print(x) 
        except StopIteration: 
            break 

main()