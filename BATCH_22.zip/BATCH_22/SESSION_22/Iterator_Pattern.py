class T_iterator: 
    def __init__(self, G): 
        self.G = G 

    def __next__(self): 
        return self.G.__next__()

class T: 
    def __init__(self, init_data_for_object_of_T): 
        if type(N) != int: 
            raise TypeError 
        # add attributes to newly created object of T 
        

    def __iter__(self): 
        def get_generator(FPL_get_generator): 
            """
            Write appropriate LOGIC to generate all objects 
            that you want to present to the for loop 
            (use yield statement)
            """
        return T_iterator(get_generator(APL_get_generator))