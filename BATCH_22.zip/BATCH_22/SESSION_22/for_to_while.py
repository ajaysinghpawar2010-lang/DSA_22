L = [10, 20, 30, 40]

print("for loop")
for x in L:
    print(x)

#------------------------

print("while loop")

I = L.__iter__()
while True:
    try:
        n = I.__next__()
        print(n)
    except StopIteration:
        break 


