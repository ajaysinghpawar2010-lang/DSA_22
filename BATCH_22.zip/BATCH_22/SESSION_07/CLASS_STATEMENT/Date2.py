class Date:
    def __init__(self):
        print("self.__dict__:", self.__dict__)
        self.day = 1
        print("self.__dict__:",self.__dict__)
        self.month = 1
        print("self.__dict__:",self.__dict__)
        self.year = 1970
        print("self.__dict__:",self.__dict__)

D = Date()
print("D.__dict__:", D.__dict__)
