Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
a = 10
def f():
    for x in [10, 20, 30]:
        print(x)

        
class Test:
    def f():
        for x in [10, 20, 30]:
            print(x)

            
for x in [10, 20, 30]:
    print(x)

    
10
20
30
class Test:
    a = 10
    b = 20
    c = a + b 
    L = [100, 200, 300]
    for x in L:
        print(x)

        
100
200
300
t1 = Test()
t2 = Test()
t1.__dict__
{}
t2.__dict__
{}
n = 10
type(n)
<class 'int'>
f = 1.2
type(f)
<class 'float'>
type(Test)
<class 'type'>
Test.__dict__
mappingproxy({'__module__': '__main__', 'a': 10, 'b': 20, 'c': 30, 'L': [100, 200, 300], 'x': 300, '__dict__': <attribute '__dict__' of 'Test' objects>, '__weakref__': <attribute '__weakref__' of 'Test' objects>, '__doc__': None})
class T:
    x = 100

    
t1 = T()
t2 = T()
t1.x
100
t2.x
100
id(t1.x)
1685371030864
id(t2.x)
1685371030864
