"""
@author: yogeshwar shukla 
@date: 4th May 2024 
@goal: to implement Date class with getters and setters 
"""

import sys 

class Date: 

    """
    Date class 
    @__init__(): constructor accepting day, month, year
    @get_day(): getter for day attribute 
    @get_month(): getter for month attribute 
    @get_year(): getter for year attribute 
    @set_day(): setter for day attribute 
    @set_month(): setter for month attribute 
    @set_year(): setter for year attribute 
    @show(): displays object contents 
    """

    @staticmethod 
    def is_valid(day: int, month: int, year: int) -> bool: 
        # find out if year is leap 
        # month == 2, year is leap, day : 1,29 
        # month == 2, year is not leap, day: 1,28
        # month in (1, 3, 5, 7, 8, 10, 12), day: 1,31 
        # month in (4, 6, 9, 11), day: 1:30
        return True 

    def __init__(self, init_day: int, init_month: int, init_year: int): 
        if type(init_day) != int or type(init_month) != int or type(init_year) != int: 
            raise TypeError("day, month, year initialisers must be ints")
        if not Date.is_valid(init_day, init_month, init_year): 
            raise ValueError("Invalid values for date")
        self.day = init_day 
        self.month = init_month 
        self.year = init_year 

    def get_day(self) -> int: 
        """
        @getter for day attribute
        """
        return self.day 
    
    def get_month(self) -> int: 
        """
        @getter for month attribute 
        """
        return self.month 
    
    def get_year(self) -> int: 
        """
        @getter for year attribute 
        """
        return self.year 
    
    def set_day(self, new_day: int) -> None: 
        """
        @setter for day attribute 
        """
        if type(new_day) != int: 
            raise TypeError("day must be int")
        if not Date.is_valid(new_day, self.month, self.year): 
            raise ValueError("Bad value for day")
        self.day = new_day 

    def set_month(self, new_month: int) -> None: 
        """
        @setter for month attribute 
        """
        if type(new_month) != int: 
            raise TypeError("month must be int")
        if not Date.is_valid(self.day, new_month, self.year): 
            raise ValueError("Bad value for month")
        self.month = new_month

    def set_year(self, new_year: int) -> None: 
        """
        @setter for year attribute 
        """
        if type(new_year) != int: 
            raise TypeError("day must be int")
        self.year = new_year 

    def show(self) -> None: 
        """
        Displays contents of Date object 
        """
        print(f'{self.day}/{self.month}/{self.year}')

def main(): 
    myDate = Date(4, 5, 2024)
    
    myDate.show()           # Date.show(myDate)
    
    myDate.set_day(5)       # Date.set_day(myDate, 5)
    myDate.set_month(10)    # Date.set_month(myDate, 10)
    myDate.set_year(2021)   # Date.set_year(myDate, 2021)
    
    myDate.show()           # Date.show(myDate)
    
    sys.exit(0)

main()