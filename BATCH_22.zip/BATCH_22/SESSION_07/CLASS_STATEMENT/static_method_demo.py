class Test: 
    def f(): 
        print("In Test.f()")

    @staticmethod 
    def g(): 
        print("In Test.g()")



t = Test() 
t.g() # Test.g() 
Test.g() 
t.f() # Test.f(t)