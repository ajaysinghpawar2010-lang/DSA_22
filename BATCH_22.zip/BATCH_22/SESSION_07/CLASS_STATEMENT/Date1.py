class Date:
    def __init__(self):
        print("Date.__init__():Entered") 
        print("Date.__init__():type(self):", type(self))
        print("Date.__init__():id(self):", id(self))
        print("Date.__init__():leaving")
        
D1 = Date()
D2 = Date()

print("id(D1):", id(D1))
print("id(D2):", id(D2))


        
