Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
class Date:
    pass

type(Date)
<class 'type'>
d1 = Date()
d2 = Date()
id(d1)
2928958608608
id(d2)
2928958196128
type(d1)
<class '__main__.Date'>
type(d2)
<class '__main__.Date'>
d1.__dict__
{}
d2.__dict__
{}
class Date:
    day = 1
    month = 1
    year = 1970

    
Date.__dict__
mappingproxy({'__module__': '__main__', 'day': 1, 'month': 1, 'year': 1970, '__dict__': <attribute '__dict__' of 'Date' objects>, '__weakref__': <attribute '__weakref__' of 'Date' objects>, '__doc__': None})
d1 = Date()
d2 = Date()
d1.__dict__
{}
d2.__dict__
{}
