import threading 
import sys 
import random 

#-------------------------STACK SERVER SIDE------------------------------------

class ThreadSafeStack: 

    def __init__(self): 
        self.lst = [] 
        self.mutex_lock = threading.Lock() 

    def push(self, new_data: int) -> None: 
        if type(new_data) != int: 
            raise TypeError("Stack accepts only integer data")
        self.mutex_lock.acquire()
        self.lst.append(new_data) 
        self.mutex_lock.release()


    def top(self) -> int: 
        self.mutex_lock.acquire()
        if len(self.lst) == 0: 
            self.mutex_lock.release()
            raise TypeError("Cannot top from empty stack")
        val = self.lst[-1]
        self.mutex_lock.release() 
        return val 

    def pop(self) -> int: 
        self.mutex_lock.acquire()
        if len(self.lst) == 0: 
            self.mutex_lock.release()
            raise TypeError("Cannot pop from empty stack")
        val = self.lst.pop()
        self.mutex_lock.release() 
        return val 

    def is_empty(self) -> bool: 
        self.mutex_lock.acquire() 
        status = len(self.lst) == 0 
        self.mutex_lock.release()
        return status 

#-------------------------STACK CLIENT SIDE------------------------------------

class TestThreadSafeStack(threading.Thread): 
    def __init__(self, thread_id: int, stack: ThreadSafeStack, 
                nr_operations: int, stdout_lock: threading.Lock
            ): 
        if type(thread_id) != int: 
            raise TypeError("thread id must an integer")
        if type(nr_operations) != int: 
            raise TypeError("Number of operations must be an int")
        if type(stack) != ThreadSafeStack: 
            raise TypeError("Must receive thread safe stack from parent")
        if thread_id <= 0: 
            raise ValueError("Thread id must be a positive integer")
        if nr_operations <= 0: 
            raise ValueError("Number of operations must be a positive integer")

        threading.Thread.__init__(self)
        self.thread_id = thread_id 
        self.stack = stack 
        self.nr_operations = nr_operations
        self.stdout_lock = stdout_lock
        
    def run(self): 
        PUSH, TOP, POP, IS_EMPTY = 1, 2, 3, 4
        for i in range(self.nr_operations): 
            op_choice = random.randint(1, 5)
            if op_choice == PUSH: 
                val = random.randint(1, 1000)
                self.stack.push(val)
                self.stdout_lock.acquire() 
                print(f'Thread id:{self.thread_id}:push:{val}')
                self.stdout_lock.release()
            elif op_choice == TOP: 
                try: 
                    val = self.stack.top()
                    self.stdout_lock.acquire() 
                    print(f'Thread id:{self.thread_id}:top:{val}')
                    self.stdout_lock.release()
                except: 
                    exc_name, exc_data, _ = sys.exc_info()
                    self.stdout_lock.acquire() 
                    print(f'Thread id:{self.thread_id}:top:{exc_name}:{exc_data}')
                    self.stdout_lock.release()
            elif op_choice == POP: 
                try: 
                    val = self.stack.pop()
                    self.stdout_lock.acquire() 
                    print(f'Thread id:{self.thread_id}:pop:{val}')
                    self.stdout_lock.release()
                except: 
                    exc_name, exc_data, _ = sys.exc_info()
                    self.stdout_lock.acquire() 
                    print(f'Thread id:{self.thread_id}:top:{exc_name}:{exc_data}')
                    self.stdout_lock.release()
            elif op_choice == IS_EMPTY: 
                status = self.stack.is_empty() 
                self.stdout_lock.acquire() 
                print(f'Thread id:{self.thread_id}:is_empty:{status}')
                self.stdout_lock.release() 

def main(argc: int, argv: list[str]) -> None: 
    if argc < 3: 
        print(f"UsageError:{argv[0]} nr_threads[2-100] nr_operations[5-5000]")
        sys.exit(0)
    
    try: 
        nr_threads = int(argv[1])
        if nr_threads not in range(2, 101): 
            raise ValueError("Number of threads must be between 2-100")
        nr_operations = int(argv[2])
        if nr_operations not in range(5, 5001): 
            raise ValueError("Number of operations must be between 5-5000")
    except: 
        exc_name, exc_data, _ = sys.exc_info() 
        print(f"{exc_name}:{exc_data}")

    print("main thread:creating thread safe stack")
    S = ThreadSafeStack() 
    print("main_thread:allocating a mutex lock for stdout")
    stdout_lock = threading.Lock() 
    thread_objects = [] 
    print(f"main thread:creating {nr_threads} threads")
    for i in range(nr_threads): 
        thread_objects.append(TestThreadSafeStack(i+1, S, nr_operations, stdout_lock))
    print(f'main thread:starting all threads')
    for thread in thread_objects: 
        thread.start() 
    print('main thread:joining with all threads')
    for thread in thread_objects: 
        thread.join() 
    print('main thread:terminating')        
    sys.exit(0)

main(len(sys.argv), sys.argv)