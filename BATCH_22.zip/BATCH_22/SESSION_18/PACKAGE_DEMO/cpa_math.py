def cpa_sin(x): 
    print("inside cpa_sin()")

def cpa_cos(x): 
    print("inside cpa_cos()")

def cpa_tan(x): 
    print("inside cpa_tan()")

class Date: 
    def __init__(self, dd, mm, yy): 
        self.day, self.month, self.year = dd, mm, yy 

    def get_day(self): return self.day 

    def get_month(self): return self.month 

    def get_year(self): return self.year 

    def set_day(self, new_day): self.day = new_day 

    def set_month(self, new_month): self.month = new_month 

    def set_year(self, new_year): self.year = new_year


if __name__ == '__main__': 
    # UNIT TESTING PACKAGE 
    print("RUNNING UNIT TEST")
    cpa_sin(0.0) 
    cpa_cos(0.0) 
    cpa_tan(0.0) 
    myDate = Date(1, 1, 1970)
    print(myDate.get_day(), myDate.get_month(), myDate.get_year())
    myDate.set_day(2)
    myDate.set_month(1)
    myDate.set_year(1969)
    print(myDate.get_day(), myDate.get_month(), myDate.get_year())
    print("DONE UNIT TEST")