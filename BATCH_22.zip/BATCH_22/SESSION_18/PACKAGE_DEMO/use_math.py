import cpa_math 

print("START OF PROGRAM")
cpa_math.cpa_sin(0.0) 
cpa_math.cpa_cos(0.0)
cpa_math.cpa_tan(0.0)

D = cpa_math.Date(1, 1, 1970)
print(D.get_day(), D.get_month(), D.get_year())
D.set_day(2)
D.set_month(3)
D.set_year(1986)
print(D.get_day(), D.get_month(), D.get_year()) 

print("END OF PROGRAM")