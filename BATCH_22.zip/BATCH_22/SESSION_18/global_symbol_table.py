print(globals())

n = 10 
print(n)

print(globals())

print("MODULE NAME:", __name__)
