import sys 


class Color: 
    RED = 1 
    BLACK = 2 


class rb_node: 
    def __init__(self, data=None, color=Color.RED, NIL=None): 
        self.data = data 
        self.color = color 
        self.left = NIL
        self.right = NIL 
        self.parent = NIL


class rb_tree: 
    NIL = rb_node(color = Color.BLACK)


    def __init__(self): 
        self.root_node = None 
        self.nr_elements = 0 
 