class edge_iterator: 
    def __init__(self, G): 
        self.G = G 
    def __iter__(self): 
        return self 
    def __next__(self): 
        return self.G.__next__() 

class graph: 
    def __init__(self): 
        pass 


    def edges(self): 
        def get_generator(self): 
            '''
            logic for extracting edges from graph 
            for every edge yield
            '''
        return edge_iterator(get_generator(self))

g = graph() 
# g.add_vertex(), g.add_edge() 
# etc 

for e in g.edges(): 
    print(e) 

# Learning Python -> 1500