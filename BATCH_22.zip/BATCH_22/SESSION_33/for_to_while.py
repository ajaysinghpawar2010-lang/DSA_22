L = [100, 200, 300, 400, 500]
print("for loop:")
for x in L: 
    print(x) 


I = L.__iter__()

print(f'type(I):{type(I)}')

while True: 
    try: 
        n = I.__next__() 
        print(n) 
    except StopIteration: 
        break 


# 1) If you want object of your class (say T) to be usable with 
# for loop in a capacity of iterable then your class T 
# must have the CORRECTLY implemented __iter__() method? 