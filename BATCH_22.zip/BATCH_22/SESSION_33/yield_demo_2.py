def func(): 
    yield True 
    yield 100 
    yield 3.14 

X = func() 
print(f'type(X):{type(X)}') # class generator 

v = X.__next__()
print(v) 
v = X.__next__() 
print(v) 
v = X.__next__() 
print(v)

try: 
    v = X.__next__()
except StopIteration: 
    print("generator object is empty now")

def func(G): 
    while True: 
        try: 
            n = G.__next__() 
            print(n) 
        except StopIteration: 
            break 

func(generator_object)

#-----------------------------------------------------
class C: 
    def __init__(self, G): 
        self.G = G 
    def __next__(self): 
        return self.G.__next__()
    
objC = C(generator_object)

while True: 
    try: 
        n = objC.__next__() 
        print(n) 
    except StopIteration: 
        break 

