def func(): 
    print("hi") # has no effect 
    yield 500

func() 