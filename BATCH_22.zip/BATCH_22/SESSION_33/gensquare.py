class Gensquare_iterator: 
    def __init__(self, G): 
        self.G = G 
    def __next__(self): 
        return self.G.__next__()

class Gensquare: 
    def __init__(self, N: int): 
        self.N = N

    def __iter__(self): 
        def get_generator(N): 
            for i in range(N): 
                yield i ** 2 
        G = get_generator(self.N)
        return Gensquare_iterator(G)

g = Gensquare(5) 

print('for loop:')
for x in g: 
    print(x) 

print('for-while')
I = g.__iter__() 
print(f'type(I):{type(I)}')
while True: 
    try: 
        n = I.__next__() 
        print(n) 
    except StopIteration: 
        break 


'''
g = Gensquare(N)
for x in g: 
    print(x) 

squares of all numbers between 0 to N-1 should be printed 
'''