'''
1) Syntax of yield statement = that of return statement 
return rhs_expr 
yield rhs_expr

2) the yield statement must be written like the return statement : as a part of body 
of the def statement. 
def some_func():
    yield rhs_expr 

3) The yield statement can be written as many times as you want. 
Unlike the return statement it DOES NOT return the control flow 
to the caller of the function. 

4) yield statement in == return statement out 

5) yield statement in == no I/O on standard input & output device 

'''