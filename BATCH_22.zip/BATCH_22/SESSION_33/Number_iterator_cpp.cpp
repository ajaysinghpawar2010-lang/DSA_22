#include <iostream>
 #include <vector> 

class Numbers{
    private: 
        std::vector<int> v; 
    public: 
        class even_iterator; 
        class odd_iterator; 
        class prime_iterator; 

        Numbers(std::initializer_list<int> i_list) : v{i_list}

        even_iterator even_begin(); 
        even_iterator even_end(); 

        odd_iterator odd_begin(); 
        odd_iterator odd_end(); 
        
        prime_iterator prime_begin(); 
        prime_iterator prime_end(); 

        class even_iterator{

        }; 

        class odd_iterator{

        }; 

        class prime_iterator{

        }; 
}; 

int main(void){
    Numbres N{2, 5, 22, 11, 34, 56, 77, 53, 42};

    std::cout << "Evens:" << std::endl; 
    for(Numbers::even_iterator iter = N.even_begin(); 
        iter != N.even_end(); 
        ++iter)
        std::cout << "*iter=" << *iter << std::endl; 

    std::cout << "Odds:" << std::endl; 
    for(Numbers::odd_iterator iter = N.odd_begin(); 
        iter != N.odd_end(); 
        ++iter)
        std::cout << "*iter=" << *iter << std::endl; 

    std::cout << "Primes:" << std::endl; 
    for(Numbers::prime_iterator iter = N.prime_begin(); 
        iter != N.prime_end(); 
        ++iter)
        std::cout << "*iter=" << *iter << std::endl; 

    return 0; 
}