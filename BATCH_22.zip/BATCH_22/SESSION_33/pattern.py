class T_iterator: 
    def __next__(self): 
        return 'next element in objT'
    

class T: 
    def __iter__(self): 
        return T_iterator() 


objT = T() 
for v in objT: 
    print("do something with v")