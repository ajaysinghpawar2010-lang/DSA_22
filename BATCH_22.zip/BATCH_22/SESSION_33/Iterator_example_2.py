class Numbers_iterator: 
    def __init__(self, G): 
        self.G = G 
    def __next__(self): 
        return self.G.__next__()

class Numbers: 
    def __init__(self, *args): 
        self.number_tuple = args
    def __iter__(self) : 
        def get_generator(self): 
            for x in self.number_tuple:
                if x % 2 == 0: 
                    yield x 
        return Numbers_iterator(get_generator(self))

N = Numbers(2, 5, 22, 11, 34, 56, 77, 53, 42)

for x in N: 
    print(x) # all even numbers in N should be printed 

