class even_iterator: 
    def __init__(self, G): 
        self.G = G 
    def __iter__(self): 
        return self 
    def __next__(self): 
        return self.G.__next__()

class odd_iterator: 
    def __init__(self, G): 
        self.G = G 
    def __iter__(self): 
        return self 
    def __next__(self): 
        return self.G.__next__()

class prime_iterator: 
    def __init__(self, G): 
        self.G = G 
    def __iter__(self): 
        return self 
    def __next__(self): 
        return self.G.__next__()

class Numbers: 
    def __init__(self, *args): 
        self.number_tuple = args

    def evens(self): 
        def get_generator(self): 
            for x in self.number_tuple: 
                if x % 2 == 0:
                    yield x
        return even_iterator(get_generator(self))

    def odds(self): 
        def get_generator(self): 
            for x in self.number_tuple: 
                if x % 2 == 1: 
                    yield x 
        return odd_iterator(get_generator(self))

    def primes(self): 
        def get_generator(self): 
            def is_prime(n): 
                if n <= 1: 
                    return False 
                if n == 2: 
                    return True 
                for k in range(2, n): 
                    if n % k == 0: 
                        return False 
                return True 
            for x in self.number_tuple: 
                if is_prime(x) == True: 
                    yield x 
        return prime_iterator(get_generator(self))
    
N = Numbers(2, 5, 22, 11, 34, 56, 77, 53, 42)

print("Evens:")
for x in N.evens(): 
    print(x)    # all even numbers must be printed 

print("Odds:")
for y in N.odds(): 
    print(y)    # all odd numbers must be printed 

print("Primes:")
for z in N.primes(): 
    print(z)    # all primes must be printed 