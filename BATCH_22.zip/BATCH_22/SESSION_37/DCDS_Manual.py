class set_node: 
    def __init__(self, data): 
        self.data = data 
        self.prev = None 
        self.next = None 

class set_list: 


    @staticmethod 
    def generic_insert(start: set_node, mid: set_node, end: set_node): 
        mid.next = end 
        mid.prev = start 
        start.next = mid 
        end.prev = mid 


    @staticmethod
    def generic_end(node: set_node): 
        node.prev.next = node.next 
        node.next.prev = node.prev 

    
    def search_node(self, data): 
        run = self.head_node.next 
        while run != self.head_node: 
            if run.data == data: 
                return run 
            run = run.next
        return None 


    def __init__(self): 
        self.head_node = set_node(None)
        self.head_node.prev = self.head_node 
        self.head_node.next = self.head_node 


    def insert_end(self, x): 
        set_list.generic_insert(self.head_node.prev, set_node(x), self.head_node)


    def __contains__(self, x): 
        ret = self.search_node(x)
        return ret is not None 
    

    def __str__(self): 
        s = '' 
        run = self.head_node.next 
        while run != self.head_node: 
            s += f'[{run.data}]->'
            run = run.next 
        s += '[END]'
        return s 


class Set: 
    def __init__(self, x = None): 
        self.lst = set_list() 
        self.r_elem = x 
        if x is not None: 
            self.lst.insert_end(x)


    def __str__(self): 
        return f'REPRESENTATIVE:{self.r_elem}, SET:{self.lst}'
    

def main(): 
    L = []
    for c in 'abcdefghi': 
        L.append(Set(c))
    for s in L: 
        print(s)


main()