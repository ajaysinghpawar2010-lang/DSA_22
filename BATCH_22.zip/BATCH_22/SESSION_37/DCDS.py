import sys 


class ValueExistsError(Exception): pass 


class InvalidRepresentativeElementError(Exception):pass


class InValidValueError(Exception): pass
 

class DCDS_iterator: 
    def __init__(self, G): 
        self.G = G 
    def __next__(self): 
        return self.G.__next__()


class DCDS: 
    def __init__(self): 
        self.S = [] 

    
    def make_set(self, x: str): 
        if type(x) != str: 
            raise TypeError(f"{x} must a string")
        
        for s in self.S: 
            if x in s: 
                raise ValueExistsError(f'{x} is already present in one of the sets in DCDS')
        
        self.S.append({'repr' : x, 'set' : {x}})


    def union(self, u: str, v: str): 
        '''
        Take union of two sets whose representative keys are u and v
        '''
        uD, vD = None, None
        for D in self.S:
            if D['repr'] == u: 
                uD = D 
            elif D['repr'] == v: 
                vD = D 
        if uD is None or vD is None: 
            raise InvalidRepresentativeElementError("bad representative element")
        for elem in vD['set']: 
            uD['set'].add(elem)    
        self.S.remove(vD)
    

    def find_set(self, u) -> dict:
        '''
        Return a set containing value u 
        '''
        for D in self.S: 
            if u in D['set']: 
                return D 
        raise InValidValueError(f'{u} does not exist in any set in DCDS')
    

    def __iter__(self): 
        def get_generator(lst): 
            for D in lst: 
                yield D['set']
        return DCDS_iterator(get_generator(self.S))
    

    def show(self): 
        print("Showing DCDS")
        for D in self.S: 
            print(f"Set with representative element:{D['repr']} : {D['set']}")

    
def main(): 
    G = {   
            'V': {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'}, 
            'E': {
                    ('a', 'b'), ('b', 'c'), ('d', 'a'), ('e', 'f'), 
                    ('f', 'g'), ('g', 'e'), ('h', 'i')
                }
        }

    dcds = DCDS() 

    for v in G['V']: 
        dcds.make_set(v)

    for (u, v) in G['E']: 
        uD = dcds.find_set(u)
        vD = dcds.find_set(v)
        if uD != vD: 
            dcds.union(uD['repr'], vD['repr'])
   
    print("Forests in Graph G")
    for sV in dcds: 
        print(sV)

    sys.exit(0) 


main() 