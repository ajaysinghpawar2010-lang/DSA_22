#include <iostream> 
#include <stdexcept> 

class vertex_invalid_error : public std::runtime_error{
    public:
        vertex_invalid_error(const char* msg) : std::runtime_error(msg){

        }
}; 

class vertex_exists_error : public std::runtime_error{
    public:
        vertex_exists_error(const char* msg) : std::runtime_error(msg){

        }
}; 

class edge_invalid_error : public std::runtime_error{
    public:
        edge_invalid_error(const char* msg) : std::runtime_error(msg){

        }
}; 

class edge_exists_error : public std::runtime_error{
    public:
        edge_exists_error(const char* msg) : std::runtime_error(msg){

        }
}; 

class graph_inconsistent_error : public std::runtime_error{
    public:
        graph_inconsistent_error(const char* msg) : std::runtime_error(msg){

        }
}; 

class hnode{
    friend class hlist; 
    friend class vnode; 
    friend class vlist; 
    friend class graph; 
    friend std::ostream& operator<<(std::ostream& os, const graph& g);

    private: 
        int v; 
        hnode* prev; 
        hnode* next; 

        hnode(int _v) : v(_v), prev(0), next(0){

        }
}; 

class hlist{
    friend class vnode; 
    friend class vlist; 
    friend class graph;
    friend std::ostream& operator<<(std::ostream& os, const graph& g);
    private: 
        hnode* head_node; 
        
        static void generic_insert(hnode* start, hnode* mid, hnode* end){
            mid->next = end; 
            mid->prev = start; 
            start->next = mid; 
            end->prev = mid; 
        }

        static void generic_delete(hnode* delete_node){
            delete_node->prev->next = delete_node->next; 
            delete_node->next->prev = delete_node->prev; 
            delete delete_node; 
        }

        hnode* search_node(int v){
            for(hnode* run = head_node->next; run != head_node; run = run->next)
                if(run->v == v)
                    return run; 
            return 0; 
        }

    public:
        hlist() : head_node(new hnode(-1)){
            head_node->prev = head_node; 
            head_node->next = head_node;
        }

        void insert_end(int v){
            hlist::generic_insert(head_node->prev, new hnode(v), head_node); 
        }
}; 

class vnode{
    friend class vlist; 
    friend class graph; 
    friend std::ostream& operator<<(std::ostream& os, const graph& g);

    private: 
        int v; 
        hlist adj_list; 
        vnode* prev; 
        vnode* next; 

        vnode(int _v) : v(_v), prev(0), next(0){

        }
}; 

class vlist{
    friend class graph; 
    friend std::ostream& operator<<(std::ostream& os, const graph& g);
    private: 
        vnode* head_node; 

        static void generic_insert(vnode* start, vnode* mid, vnode* end){
            mid->next = end; 
            mid->prev = start; 
            start->next = mid; 
            end->prev = mid; 
        }

        static void generic_delete(vnode* delete_node){
            delete_node->prev->next = delete_node->next; 
            delete_node->next->prev = delete_node->prev; 
            delete delete_node; 
        }

        vnode* search_node(int v){
            for(vnode* run = head_node->next; run != head_node; run = run->next)
                if(run->v == v)
                    return run; 
            return 0; 
        }

        public: 
            vlist() : head_node(new vnode(-1)){
                delete this->head_node->adj_list.head_node; 
                head_node->prev = head_node; 
                head_node->next = head_node; 
            }
}; 

class graph{
    private: 
        vlist v_list; 
        size_t nr_elements; 
        size_t nr_edges; 
    public: 
        // create_graph() 
        graph() {
            //TODO
        }   
        
         // destroy_graph() 
        ~graph() {
            //TODO
        } 
        
        void add_vertex(int v){
            //TODO
        }

        void remove_vertex(int v){
            //TODO
        }

        void add_edge(int v_start, int v_end){
            //TODO
        }

        void remove_edge(int v_start, int v_end){
            //TODO
        }

        friend std::ostream& operator<<(std::ostream& os, const graph& g); 


}; 

std::ostream& operator<<(std::ostream& os, const graph& g){
    //TODO
}

int main(void){
    // TODO

    return 0; 
}