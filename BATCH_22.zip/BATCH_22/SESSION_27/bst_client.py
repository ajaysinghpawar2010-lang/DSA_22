class bst: 
    pass 


def main(): 
    T = bst() 

    existing_data = None 
    data = T.preorder_predecessor(existing_data)
    print(data)
    data = T.postorder_predecessor(existing_data)
    print(data)
    data = T.preorder_successor(existing_data)
    print(data)
    data = T.postorder_succcessor(existing_data)
    print(data)

    T.inorder_nrc() # nrc = non-recursive traversal 
    T.preorder_nrc() 
    T.postorder_nrc() 


main()
