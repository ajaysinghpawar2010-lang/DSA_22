print("start of code")
L = [10, 20, 30, 40, 50, 15]
print("BEFORE:L:", L)
key = L[len(L) - 1]

i = len(L)-2
while i > -1 and L[i] > key:
    L[i+1] = L[i]
    i = i - 1

L[i+1] = key

print("AFTER:L:", L)

print("end of code")
