Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print("Hello, DSA World")
Hello, DSA World
>>> 
= RESTART: C:/Users/yoges/OneDrive/Documents/CPA/DS_ALG/BATCH_CODES/BATCH_22/OPEN_FOR_ALL_SESSIONS/DAY_2_SRC/insert_at_sorting_pos.py
BEFORE:L: [10, 20, 30, 40, 50, 15]
AFTER:L: [10, 15, 20, 30, 40, 50]
>>> b = True
>>> n = 15
>>> fnum = 3.1
>>> print(b)
True
>>> print(n)
15
>>> print(fnum)
3.1
>>> type(b)
<class 'bool'>
>>> type(n)
<class 'int'>
>>> type(fnum)
<class 'float'>
>>> id(b)
140719995485840
>>> id(n)
140719996279672
>>> id(fnum)
2116956362416
>>> L = [10, 20, 30]
print(L)
[10, 20, 30]
type(L)
<class 'list'>
id(L)
2116919218944
L[0]
10
id(L[0])
140719996279512
id(L[1])
140719996279832
id(L[2])
140719996280152
L[0]
10
L[1]
20
L[2]
30
L = [10, 20, 30, 40, 50, 15]
n = len(L)
n
6
L[0]
10
L[1]
20
L[2]
30
L[3]
40
L[4]
50
L[5]
15
len(L)
6
len(L)-1
5
L[5]
15
L[len(L)-1]
15
L[len(L)-2]
50
len(L)
6
len(L)-2
4
i = len(L)-2
i
4
L[i]
50
L[4]
50
