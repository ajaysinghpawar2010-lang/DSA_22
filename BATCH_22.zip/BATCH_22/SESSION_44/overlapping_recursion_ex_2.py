'''
Function a(m, n) defined as follows: 
    a(m, n) = (m-1) * a(m-1, n) + (n-1) * a(m, n-1) if m, n > 1 
    a(m, 1) = m^2 
    a(1, n) = n^3
    a(1, 1) = 1 
'''

from time import time 

def a(m, n): 
    assert type(m) == int and type(n) == int and m > 0 and n > 0, "bad values/types"
    
    if m == 1 and n == 1: 
        return 1 

    if m == 1: 
        return n**3
    
    if n == 1: 
        return m**2 

    return (m-1) * a(m-1, n) + (n-1) * a(m, n-1)

start = time()
print(f'a(15, 15):{a(15, 15)}')
end = time() 
print("required time:", end - start)