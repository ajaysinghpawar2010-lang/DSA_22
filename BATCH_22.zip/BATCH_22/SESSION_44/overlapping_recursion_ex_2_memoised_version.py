'''
Function a(m, n) defined as follows: 
    a(m, n) = (m-1) * a(m-1, n) + (n-1) * a(m, n-1) if m, n > 1 
    a(m, 1) = m^2 
    a(1, n) = n^3
    a(1, 1) = 1 
'''

# HINT : Use class statement: so that you can keep your table 
# persistent across the recursive calls ! 

from time import time 

class A: 
    def __init__(self, m: int, n:int): 
        assert type(m) == int and type(n) == int and m > 0 and n > 0, "bad value/type"
        self.m = m 
        self.n = n 
        self.memo = [[0 for j in range(n+1)] for i in range(m+1)]
        print(self.memo)

    
    def solve(self): 

        def a(m, n): 
            if self.memo[m][n] > 0: 
                return self.memo[m][n]
            
            if m == 1 and n == 1: 
                self.memo[m][n] = 1
                return self.memo[m][n]
            
            if m == 1: 
                self.memo[m][n] = n**3
                return self.memo[m][n]
            
            if n == 1: 
                self.memo[m][n] = m**2 
                return self.memo[m][n]

            self.memo[m][n] = (m-1) * a(m-1, n) + (n-1) * a(m, n-1)
            return self.memo[m][n]

        return a(self.m, self.n)


if __name__ == '__main__': 
    print(f'A(5, 3).solve():{A(5, 3).solve()}')
    objA = A(15, 15)
    start = time()
    val = objA.solve()
    end = time()
    print('val:', val)
    print('time:', end-start)
    
    ans = int(input("Show table?[1] for yes: [0] for no:"))
    if ans == 1: 
        for i in range(objA.m + 1): 
            for j in range(objA.n +1): 
                print(f'objA.memo[{i}][{j}]: {objA.memo[i][j]}')