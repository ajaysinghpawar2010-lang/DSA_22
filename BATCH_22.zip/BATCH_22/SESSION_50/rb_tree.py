import sys 


class Color: 
    RED = 1 
    BLACK = 2 


class rb_node: 
    def __init__(self, data=None, color=Color.RED, NIL=None): 
        self.data = data 
        self.color = color 
        self.left = NIL
        self.right = NIL 
        self.parent = NIL


class rb_tree: 
    NIL = rb_node(color = Color.BLACK)
    NIL.left, NIL.right, NIL.parent = NIL, NIL, NIL


    def rb_insert_fixup(self, z: rb_node): 
        assert type(z) != rb_node, "rb_insert_fixup:bad type"

        while z.parent.color == Color.RED: 
            if z.parent == z.parent.parent.left: 
                y = z.parent.parent.right
                if y.color == Color.RED: 
                    z.parent.color = Color.BLACK 
                    y.color = Color.BLACK 
                    z.parent.parent.color = Color.RED 
                    z = z.parent 
                else: 
                    if z == z.parent.right: 
                        z = z.parent 
                        self.left_rotate(z)
                    z.parent.color = Color.BLACK 
                    z.parent.parent.color = Color.RED 
                    self.right_rotate(z.parent.parent)
                    
            else: 
                y = z.parent.parent.left 
                if y.color == Color.RED: 
                    z.parent.color = Color.BLACK 
                    y.color = Color.BLACK 
                    z.parent.parent.color = Color.RED 
                    z = z.parent  
                else: 
                    if z == z.parent.left: 
                        z = z.parent 
                        self.right_rotate(z)
                    z.parent.color = Color.BLACK 
                    z.parent.parent.color = Color.RED 
                    self.left_rotate(z.parent.parent)
                    
        if self.root_node.color == Color.RED: 
            self.root_node.color = Color.BLACK

    def __init__(self): 
        self.root_node = None 
        self.nr_elements = 0 


    def insert(self, new_data: int) -> None: 
        z = rb_node(data=new_data, NIL=rb_tree.NIL)
        if self.root_node is None: 
            self.root_node = z 
            self.rb_insert_fixup(z) 
            return None 
        
        run = self.root_node 
        while True: 
            if new_data <= run.data: 
                if run.left is rb_tree.NIL: 
                    run.left = z 
                    z.parent = run 
                    break 
                else: 
                    run = run.left 
            else: 
                if run.right is rb_tree.NIL: 
                    run.right = z 
                    z.parent = run 
                    break 
                else: 
                    run = run.right 
        self.rb_insert_fixup(z)
        return None 
 