def Fibbonacci(N: int) -> int: 
    if type(N) != int: raise TypeError 
    if N < 0: raise ValueError 

    T = [0 for i in range(N+1)] 

    def compute(n): 
        nonlocal T 
        if n == 0: 
            return 0 
        elif n == 1: 
            return 1 
        elif n > 1 and n < len(T) and T[n] > 0:  
            return T[n] 
        else: 
            tmp = compute(n-1) + compute(n-2)
            T[n] = tmp
            return T[n]


    result = compute(N)
    return result

Fib(N)

for n in range(800): 
    result = Fibbonacci(n)
    print(f"Fib({n}):{result}")