'''
@goal: goal of this application is to write a function to find out 
nth Fiibonacci number. 

F0 = 0 
F1 = 1 
Fn = Fn-1 + Fn-2 
'''

from time import time 

def Fibbonacci(N: int): 
    if N == 0: 
        return 0 
    elif N == 1: 
        return 1 
    else: 
        return Fibbonacci(N-1) + Fibbonacci(N-2)


t1 = time() 
result = Fibbonacci(45)
t2 = time() 
print("result:", result)
print("delta:", t2-t1)

# MEMO : TABLE 
# MEMOIZATION