class Numbers: 
    def __init__(self, *args): 
        self.T = args 

