def find_max(L: list[int]):
    pass

find_max()