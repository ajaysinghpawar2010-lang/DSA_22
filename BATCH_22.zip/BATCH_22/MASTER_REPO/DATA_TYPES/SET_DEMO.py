# the purpose of this program is to illustrate set operations 
import sys 

def main(): 
	line = "-" * 65
	# A.ways of creation 
	print("A.Ways of creation")
	S = {10, 20, 30 ,40}
	print("explicit:S:", S)
	print(line)
	# constructor 
	s = "Hello"
	L = [True, 10, 3.14, 500]
	T = (10, 20, 30)
	S1 = set(s)
	S2 = set(L)
	S3 = set(T)
	print("constructorS1:{} S2:{} S3:{}".format(S1, S2, S3))
	print(line)

	# B.Built in functions with which set object works 
	print("B.Built in fucntions with which set object works")
	S = {10, 20, 30, 40}
	print("S:", S)
	print("type(S):", type(S))
	print("id(S):", id(S))
	print("len(S):", len(S))
	print(line)
	# C. Built in operators with which set object works 
	S = {10, 20, 30, 40}
	b = (10 in S)
	print("in operator:10 in S:", b)
	print("traversal:iterator based")
	for x in S:
		print("x:", x)	
	print(line)

	# D. class methods supported by set 
	# union, intersection, difference, symmetric difference (immutable versions)
	S1 = {10, 20, 30, 40, 50}
	S2 = {30, 40, 50, 60, 70}
	Su = S1.union(S2)
	Si = S1.intersection(S2)
	Sd = S1.difference(S2)
	Ssd = S2.symmetric_difference(S1)
	print("immutable:Union:{} intersection:{}\ndifference:{} symmetric_difference:{}".format(Su, Si, Sd, Ssd))
	print(line)
	# union, intersection, difference, symmetric difference (mutable versions)
	S1.update(S2)
	print("mutable union:S1:", S1)
	print(line)

	S1 = {10, 20, 30, 40, 50}
	S2 = {30, 40, 50, 60, 70}
	S1.intersection_update(S2)
	print("mutable intersection:S1:", S1)
	print(line)

	S1 = {10, 20, 30, 40, 50}
	S2 = {30, 40, 50, 60, 70}
	S1.difference_update(S2)
	print("mutable difference:S1:", S1)
	print(line)

	S1 = {10, 20, 30, 40, 50}
	S2 = {30, 40, 50, 60, 70}
	S1.symmetric_difference_update(S2)
	print("mutable symmetric difference:S1:", S1)
	print(line)

	# issubset, issuperset, isdisjoint
	S1 = {10, 20, 30}
	S2 = {10, 20, 30, 40, 50}
	b1 = S1.issubset(S1)
	b2 = S1.issuperset(S1)
	print("S1.issubset(S1):{} S1.issuperset(S1):{}".format(b1, b2))
	b3 = S1.issubset(S2)
	b4 = S2.issubset(S1)
	print("S1.issubset(S2):{} S2.issubset(S1):{}".format(b3, b4))
	b5 = S1.issuperset(S2)
	b6 = S2.issuperset(S1)
	print("S1.issuperset(S2):{} S2.issuperset(S1):{}".format(b5, b6))
	print(line)

	# Create empty set 
	S = set()
	# adding element to set
	print("before add:S:", S) 
	S.add(True)
	S.add(10)
	S.add("Hello")
	S.add(20)
	S.add(30)
	S.add(40)
	print("add:S:", S)
	print(line)

	# remove
	S.remove(20)
	print("remove:S.remove(20):", S)

	# discard
	S.discard(10) # works 
	S.discard(-1) # does not generate exception 
	print("discard:S:", S)

	# pop = remove + return
	print("before pop:S:", S) 
	n = S.pop() 
	print("pop:n:", n)
	n = S.pop()
	print("pop:n:", n)
	print(line)

	# copy
	print("S:{} id(S):{}".format(S, id(S)))
	SC = S.copy()
	print("SC:{} id(SC):{}".format(SC, id(SC)))
	print(line)

	# clear 
	print("before clear:S:", S)
	S.clear()
	print("after clear:S:", S)
	print(line)

	sys.exit(0) 

main()