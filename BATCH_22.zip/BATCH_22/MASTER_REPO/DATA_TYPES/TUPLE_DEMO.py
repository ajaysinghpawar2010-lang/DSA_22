# The purpose of this program is to illustrate the tuple operations 

import sys 

def main(): 

	line = "-" * 65
	# ways of creation 
	print("(A):Ways of creation")
	T1 = (10, 20, 30)
	T2 = (True, 10, 3.14, "Hello", {100, 200, 300})
	print("explicit:T1:{} T2:{}".format(T1, T2))
	print(line)
	
	s = "Hello"
	L = [100, 200, 300]
	T1 = tuple(s)
	T2 = tuple(L)
	print("constructor approach:T1:{} T2:{}".format(T1, T2))
	print(line)
	
	T = (10, )
	print("length one tuple:T:", T)
	print(line)

	# Built in functions with which tuple object works 
	print("(B):Built in functions with which tuple object works")
	T = (10, 20, 30, 40)
	print("T:", T)
	print("type(T):", type(T))
	print("len(T):", len(T))
	print("id(T):", id(T))
	print(line)

	# Built in operators with which tuple object works 
	print("(C):Built in operators with which tuple object works")
	# Concat
	T1 = (10, 20 ,30)
	T2 = (40, 50 ,60)
	T3 = T1 + T2
	print("Concat:T1:{} T2:{} T3:{}".format(T1, T2, T3))
	print(line)

	# Multiplication by scalar
	T = (10, 20, 30)
	T_mul = T * 4
	print("T:{} T_mul:{}".format(T, T_mul))
	print(line)

	# index, range, slice on rhs 
	T = (10, 20, 30, 40, 50, 60, 70, 80, 90, 100)
	n = T[5]
	print("index:T[5]:n:", n)
	print("range:T[2:5]:{}".format(T[2:5]))
	print("range:T[-5:-2]:{}".format(T[-5:-2]))
	print("range:T[:4]:{}".format(T[:4]))
	print("slice:T[1:6:2]:{}".format(T[1:6:2]))
	print("slice:T[-6:-1:2]:{}".format(T[-6:-1:2]))
	print("slice:T[::-1]:{}".format(T[::-1]))
	print(line)

	# in operator
	T = (10, 20, 30, 40)
	b = (10 in T)
	print("10 in T:", b)
	b = (100 in T)
	print("100 in T:", b)
	print(line)

	print("(D):Class methods:")
	# index method, count method 
	T = (10, 20, 30, 40 ,50, 10, 60, 70, 80, 10, 90, 100)
	n = T.index(10)
	m = T.index(10, n+1)
	k = T.index(10, m+1)
	print("index:10 in T at indices first:{} second:{} third:{}".format(n,m,k))
	n = T.count(10)
	print("count:T.count(10):{}".format(n))
	print(line)

	# Traverse 
	print("traverse through tuple by two methods")
	print("iterator method")
	T = (10, 20, 30 ,40)
	for x in T:
		print("x:", x)
	print("index method")
	for i in range(len(T)):
		print("T[{}]:{}".format(i, T[i]))
	print(line)
	
	sys.exit(0) 

main()
