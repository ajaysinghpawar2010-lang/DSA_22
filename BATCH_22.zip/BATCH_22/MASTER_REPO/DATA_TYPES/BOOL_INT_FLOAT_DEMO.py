import sys 

def main(): 
    # Bool Data Type
    # Creation 
    b1 = False
    b2 = True 
    
    # Built in functions 
    print("b1:", b1, "b2:", b2)
    print("type(b1):", type(b1), "type(b2):", type(b2))
    print("id(b1):", id(b1), "id(b2):", id(b2)) 
    
    # Operations
    # Negation 
    b3 = (not b1) 
    b4 = (not b2)
    print("b3:", b3, "b4:", b4) 

    # Conjunction (ANDING) 
    print("b1 and b1:", b1 and b1)
    print("b1 and b2:", b1 and b2)
    print("b2 and b1:", b2 and b1) 
    print("b2 and b2:", b2 and b2) 

    # Disjunction (ORING) 
    print("b1 or b1:", b1 or b1)
    print("b1 or b2:", b1 or b2)
    print("b2 or b1:", b2 or b1)
    print("b2 or b2:", b2 or b2) 

    # Integer data type 
    n1 = 20 
    n2 = 7 
    print("n1 + n2", n1 + n2)       # Addition 
    print("n1 - n2:", n1 - n2)      # Subtraction 
    print("n1 * n2:", n1 * n2)      # Multiplication 
    print("n1 // n2:", n1 // n2)    # Integer division or floor division
    print("n1 % n2:", n1 % n2)      # Remainder (modulus) 
    print("n1 / n2:", n1 / n2)      # Floating division (True division) 
    print("n1 ** n2:", n1 ** n2)    # Power operation 

    # Arbitrary precision arithmetic of integers 
    n1 = 28450925803295
    n2 = 38509385093582095843095820543
    n3 = n1 * n2 
    print("n1:", n1)
    print("n2:", n2)
    print("n3 = n1 * n2:", n3) 
    
    # Creating integer from strings 
    s = "432" 
    print("type(s):", type(s))
    n = int(s)
    print("n:", n, "type(n):", type(n)) 

    # Creating integer from floating point numbers 
    # Fractional part will be truncated 
    f = 3.145
    print("f:", f, "type(f):", type(f))
    m = int(f)
    print("m:", m, "type(m):", type(m)) 

    # Creating integer from boolean 
    b1 = False
    b2 = True 
    n1 = int(b1)
    n2 = int(b2) 
    print("n1:", n1, "type(n1):", type(n1)) 
    print("n2:", n2, "type(n2):", type(n2)) 

    # Floating point operations 
    f1 = 3.14
    f2 = 6.28 
    
    # Built-in functions 
    print("f1:", f1, "type(f1):", type(f1))
    print("f2:", f2, "type(f2):", type(f2))
    print("id(f1):", id(f1), "id(f2):", id(f2)) 

    # Operations 
    print("f1+f2:", f1+f2)
    print("f1-f2:", f1-f2)
    print("f1*f2:", f1*f2)
    print("f1/f2:", f1-f2)
    print("f1**f2:", f1**f2)

    # Creating float from string 
    s = "6.433" 
    print("type(s):", type(s))
    f = float(s)
    print("f:", f, "type(f):", type(f)) 

    # Creating float from int 
    m = 549
    print("m:", m, "type(m):", type(m))
    f = float(m)
    print("f:", f, "type(f):", type(f)) 

    sys.exit(0) 

main() 
    

