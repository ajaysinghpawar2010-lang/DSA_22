from sys import exc_info 

class Node: 
    def __init__(self, new_data: any): 
        self.data = new_data 
        self.next = None 

class SinglyCircularLinkedList: 
    def __init__(self): 
        self.head_node = Node(None) 
        self.head_node.next = self.head_node 

    
    def insert_start(self, new_data: any) -> None: 
        new_node = Node(new_data)
        new_node.next = self.head_node.next 
        self.head_node.next = new_node 


    def insert_end(self, new_data: any) -> None: 
        run = self.head_node 
        while run.next != self.head_node: 
            run = run.next 
        new_node = Node(new_data)
        new_node.next = run.next 
        run.next = new_node 

    
    def insert_after(self, e_data: any, new_data: any) -> None: 
        run = self.head_node.next 
        while run != self.head_node: 
            if run.data == e_data: 
                break 
            run = run.next 
        else: 
            raise ValueError(f'Bad data:{e_data}')
        
        new_node = Node(new_data) 
        new_node.next = run.next 
        run.next = new_node 


    def insert_before(self, e_data: any, new_data: any): 
        run = self.head_node.next 
        run_prev = self.head_node 
        while run != self.head_node: 
            if run.data == e_data: 
                break 
            run_prev = run 
            run = run.next 
        else: 
            raise ValueError(f'Bad existing data:{e_data}')
        
        new_node = Node(new_data) 
        new_node.next = run 
        run_prev.next = new_node 


    def get_start(self) -> any: 
        if self.head_node.next == self.head_node: 
            raise ValueError("List empty")
        return self.head_node.next.data 


    def get_end(self) -> any: 
        if self.head_node.next == self.head_node: 
            raise ValueError("List empty")
        run = self.head_node 
        while run.next != self.head_node: 
            run = run.next 
        return run.data 

    
    def pop_start(self) -> any: 
        if self.head_node.next == self.head_node: 
            raise ValueError("List empty")
        data = self.head_node.next.data 
        first_node_with_data = self.head_node.next 
        self.head_node.next = first_node_with_data.next 
        del first_node_with_data 
        return data 

    
    def pop_end(self) -> any: 
        if self.head_node.next == self.head_node: 
            raise ValueError("List empty")
        run = self.head_node.next 
        run_prev = self.head_node 
        while run.next != self.head_node: 
            run_prev = run 
            run = run.next 
        data = run.data 
        run_prev.next = self.head_node 
        del run 
        return data 


    def remove_start(self) -> any: 
        if self.head_node.next == self.head_node: 
            raise ValueError("List empty") 
        first_node_with_data = self.head_node.next 
        self.head_node.next = first_node_with_data.next 
        del first_node_with_data 

    def remove_end(self) -> any: 
        if self.head_node.next == self.head_node: 
            raise ValueError("List empty") 
        run = self.head_node.next 
        run_prev = self.head_node 
        while run.next != self.head_node: 
            run_prev = run 
            run = run.next 
        run_prev.next = self.head_node 
        del run 

    def remove_data(self, r_data: any) -> any: 
        run = self.head_node.next 
        run_prev = self.head_node 

        while run != self.head_node: 
            if run.data == r_data: 
                break 
            run_prev = run 
            run = run.next 
        else: 
            raise ValueError(f"bad value for {r_data}")

        run_prev.next = run.next 
        del run 


    def find(self, find_data: any) -> bool: 
        run = self.head_node.next 
        while run != self.head_node: 
            if run.data == find_data: 
                return True 
            run = run.next 
        return False 


    def is_empty(self) -> bool: 
        return self.head_node.next == self.head_node 


    
    def get_length(self) -> int: 
        count = 0 
        run = self.head_node.next 
        while run != self.head_node: 
            count += 1 
            run = run.next 
        return count 

    def show(self, msg = None) -> None: 
        if msg is not None: 
            print(msg)
        print("[START]->", end='')
        run = self.head_node.next 
        while run != self.head_node: 
            print(f'[{run.data}]->', end='')
            run = run.next 
        print('[END]')
        

L = SinglyCircularLinkedList()

L.show() 

L.insert_end(10)
L.insert_end(20)
L.insert_end(30)
L.insert_end(40)

L.show("After insert_end()") 

L.insert_start(100)
L.insert_start(200)
L.insert_start(300)

L.show("After isnert_start():")

L.insert_after(100, 500)
L.insert_after(40, 50)

L.show("After insert_after():") 

try: 
    L.insert_after(-450, 1000)
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

L.insert_before(50, 368)
L.insert_before(100, 491)

L.show("After insert_before():") 

try: 
    L.insert_before(-450, 1000)
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)
    
try: 
    data = L.get_start()  
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

print(f'start_data:{data}')
L.show("after get_start()") 

try: 
    data = L.get_end()   
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

print(f'end_data:{data}')
L.show("after get_end()") 

try: 
    data = L.pop_start() 
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

print(f'start_data:{data}')
L.show('after pop_start()') 

try: 
    data = L.pop_end()   
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)
print(f'end_data:{data}')
L.show('after pop_end()') 

try: 
    data = L.remove_start() 
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

L.show('after remove_start()') 

try: 
    data = L.remove_end()  
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

L.show('after remove_end()') 

try: 
    data = L.remove_data(10)  
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

L.show('after remove_data()') 

n = L.get_length() 
print(f"length(L)=={n}")

ret = L.find(500) 
if ret == True: 
    print(f'500 is present in list')

ret = L.find(-1)
if ret == False: 
    print("-1 is not present in list")