class Node: 
    def __init__(self, new_data): 
        self.data = new_data 
        self.next = None 

class SinglyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)

    
    def insert_start(self, new_data): 
        nn = Node(new_data)
        nn.next = self.head_node.next 
        self.head_node.next = nn 

    
    def __len__(self): 
        cnt = 0 
        run = self.head_node.next 
        while run is not None: 
            cnt = cnt + 1 
            run = run.next 
        return cnt 

    
    def __contains__(self, new_data): 
        run = self.head_node.next 
        while run is not None: 
            if run.data == new_data: 
                return True 
            run = run.next 
        return False 


    def __str__(self): 
        op_str = '[START]->'
        run = self.head_node.next 
        while run is not None: 
            op_str = op_str + f'[{run.data}]->'
            run = run.next 
        op_str += '[END]\n'
        return op_str 
    

L = SinglyLinkedList() 
L.insert_start(100)
L.insert_start(200)
L.insert_start(300)
L.insert_start(400)
print("After insert_start:", L) 

print(f"length of L == {len(L)}")

print("100 in L:", 100 in L) # 100 in L == L.__contains__(100) == list.__contains__(L, 100)
print("200 in L:", 200 in L)
print("300 in L:", 300 in L)
print("400 in L:", 400 in L)

print("-500 in L:", -500 in L)
print("7621 in L:", 7621 in L)

"""
BUILT IN LIST L warche operations 
L1 = [10, 20, 30, 40]
L2 = [50, 60, 70, 80]
L3 = L1 + L2
L4 = L * n

10 in L1 == True 
80 in L2 == True 

-1 in L1 == True 
-50 in L1 == True 

# ITERATOR DESIGN PATTERN
# __iter__, __next__, yield 
for x in L: 
    print(x)

print(L) # done for singly linked list 
len(L) # done for singly linked list 
"""