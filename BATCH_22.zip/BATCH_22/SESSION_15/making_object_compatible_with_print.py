class Date: 
    def __init__(self, init_day, init_month, init_year): 
        self.day = init_day 
        self.month = init_month 
        self.year = init_year 
    
    
    def __str__(self): 
        return f'{self.day}/{self.month}/{self.year}'


D = Date(1, 6, 2024)
print(D) 

