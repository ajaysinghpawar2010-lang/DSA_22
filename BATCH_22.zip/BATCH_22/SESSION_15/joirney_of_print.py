n = 10
print(n)

n.__str__() -> string representation of n -> str.__str__(string representation of n)
-> sys.fwrite(string representation of n) -> os.write(string presentation of n)
-> Python / C integration -> C programming lang (windows WriteConsole vs Linux write)
