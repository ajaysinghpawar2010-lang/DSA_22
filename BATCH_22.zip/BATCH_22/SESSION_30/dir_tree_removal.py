import os 
import os.path 

def remove_r(path_name: str): 
    if not os.path.exists(path_name): 
        raise FileNotFoundError(f"{path_name} invalid")
    for file_name in os.listdir(path_name): 
        if os.path.isdir(os.path.join(path_name, file_name)): 
            if file_name == '.' or file_name == '..': 
                continue 
            abs_path = os.path.join(path_name, file_name)
            remove_r(abs_path)    
        else: 
            os.remove(os.path.join(path_name, file_name))
    os.rmdir(path_name)


def main(): 
    path_name = r'C:\Users\yoges\OneDrive\Documents\CPA\DS_ALG\BATCH_CODES\BATCH_22\SESSION_30\SRC'
    remove_r(path_name)

main()

for (dir_name, nondir_list, dir_list) in os.walk(dir_path): 
    print(dir_name)
    for nested_dirs in dir_list: 
        print("\t", nested_dirs)
    for files in nondir_list: 
        print("\t", files)

        
