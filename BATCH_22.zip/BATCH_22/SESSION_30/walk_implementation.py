for file_name in os.listdir(path_name): 
    nondir_list = [] 
    dir_list = [] 
    if os.path.isdir(os.path.join(path_name, file_name): 
        dir_list.append(file_name)
    else: 
        nondir_list.append(file_name)
yield (path_name, nondir_list, dir_list)

for file_name in os.listdir(path_name): 
    if os.path.isdir(os.path.join(path_name, file_name): 
        "RECURSIVELY APPLY"


class walk_iterator: 
    def __init__(self, G): 
        self.G = G 
    def __next__(self): 
        self.G.__next__() 

class walk: 
    def __init__(self, path_name): 
        self.path_name = path_name 

    def __iter__(self): 
        def get_generator(path_name): 
            pass 
             

        return walk_iterator(get_generator(self.path_name))