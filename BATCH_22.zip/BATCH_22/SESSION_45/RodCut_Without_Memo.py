import sys 
import math 

def max2(a, b): 
    if a > b: 
        return a 
    return b 

class RodCut: 
    def __init__(self, n: int, p: dict): 
        assert type(n) == int and n > 0, "Bad type/length of the rod"
        self.n = n
        self.p = p 
        self.q = -math.inf

    def revenue(self, n: int) -> int: 
        if n == 0: 
            return 0 
        for i in range(1, n+1): 
            self.q = max2(self.q, self.p[i] + self.revenue(n - i))
        return self.q 

def main(): 
    RC = RodCut(10, dict(zip(range(1, 11), [1, 5, 8, 9, 10, 17, 17, 20, 24, 30])))
    max_revenue = RC.revenue(10) 
    print(f'Max revenue:{max_revenue}')


main()