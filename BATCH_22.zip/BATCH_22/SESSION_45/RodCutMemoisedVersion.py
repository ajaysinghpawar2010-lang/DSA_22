import sys 
import math 

class RodCut:  
    @staticmethod 
    def max2(a, b): 
        if a > b: 
            return a 
        return b 
    
    
    def __init__(self, n: int, p: dict): 
        assert type(n) == int and n > 0, "Bad type/length of the rod"
        self.n = n
        self.p = p 
        self.q = -math.inf
        self.r = [-math.inf for i in range(n+1)]

    
    def revenue(self, n: int): 
        if n == 0: 
            return 0 
        elif self.r[n] >= 0: 
            return self.r[n]
        else: 
            self.q = -math.inf
            for i in range(1, n+1): 
                self.q = RodCut.max2(self.q, self.p[i] + self.revenue(n - i))
            self.r[n] = self.q 
            return self.r[n]


    def get_soln(self): 
        return self.r[self.n]


def main(): 
    RC = RodCut(10, dict(zip(range(1, 11), [1, 5, 8, 9, 10, 17, 17, 20, 24, 30])))
    RC.revenue(10) 
    print(f'Max Revenue:{RC.get_soln()}')


main()