'''
@author: Yogeshwar 
@goal: General implemenation of RB Tree 
@cmdline: 
# python rb_tree N 
where N is number of random integers to be inserted in tree 
For reasonable output keep N <= 1000 

For extrement testing remove calls to print() and inorder() 
traversal and you stretch N upto 1 billion and beyond 
'''

import sys 


class Color: 
    RED = 1 
    BLACK = 2 


class rb_node: 
    def __init__(self, data=None, color=Color.RED, NIL=None): 
        self.data = data 
        self.color = color 
        self.left = NIL
        self.right = NIL 
        self.parent = NIL


class rb_tree: 
    NIL = rb_node(color = Color.BLACK)
  
    @staticmethod 
    def _height(root_node: rb_node): 
        if root_node == rb_tree.NIL: 
            return 0 
        return max( rb_tree._height(root_node.left), 
                    rb_tree._height(root_node.right)
                ) + 1 

    @staticmethod 
    def _inorder(root_node: rb_node): 
        if root_node is not rb_tree.NIL:  
            rb_tree._inorder(root_node.left)
            print(f'[{root_node.data}]<->', end='')
            rb_tree._inorder(root_node.right)


    @staticmethod 
    def search_node(root_node: rb_node, n: int) -> rb_node: 
        run = root_node 
        while run is not rb_tree.NIL or run is not None: 
            if run.data == n: 
                break
            elif n < run.data: 
                run = run.left 
            else: 
                run = run.right 
        return run 
    

    def __init__(self): 
        self.root_node = None 
        self.nr_elements = 0 


    def rb_transplant(self, u: rb_node, v: rb_node) -> None: 
        if u.parent is rb_tree.NIL: 
            self.root_node = v 
        elif u == u.parent.left: 
            u.parent.left = v 
        else: 
            u.parent.right = v 
        if v is not rb_tree.NIL: 
            v.parent = u.parent 


    def left_rotate(self, x: rb_node): 
        y = x.right 
        x.right = y.left
        if y.left is not rb_tree.NIL: 
            y.left.parent = x 
        y.parent = x.parent 
        if x.parent == rb_tree.NIL: 
            self.root_node = y 
        elif x == x.parent.left: 
            x.parent.left = y 
        else: 
            x.parent.right = y 
        y.left = x 
        x.parent = y 


    def right_rotate(self, x: rb_node): 
        y = x.left 
        x.left = y.right
        if y.right is not rb_tree.NIL: 
            y.right.parent = x 
        y.parent = x.parent 
        if x.parent == rb_tree.NIL: 
            self.root_node = y 
        elif x == x.parent.left: 
            x.parent.left = y 
        else: 
            x.parent.right = y 
        y.right = x 
        x.parent = y  


    def rb_insert_fixup(self, z: rb_node): 
        assert type(z) == rb_node, "rb_insert_fixup:bad type"

        while z.parent.color == Color.RED: 
            if z.parent is z.parent.parent.left: 
                y = z.parent.parent.right
                if y.color == Color.RED: 
                    z.parent.color = Color.BLACK 
                    y.color = Color.BLACK 
                    z.parent.parent.color = Color.RED 
                    z = z.parent.parent
                else: 
                    if z == z.parent.right: 
                        z = z.parent 
                        self.left_rotate(z)
                    z.parent.color = Color.BLACK 
                    z.parent.parent.color = Color.RED 
                    self.right_rotate(z.parent.parent)  
            else: 
                y = z.parent.parent.left 
                if y.color == Color.RED: 
                    z.parent.color = Color.BLACK 
                    y.color = Color.BLACK 
                    z.parent.parent.color = Color.RED 
                    z = z.parent.parent 
                else: 
                    if z == z.parent.left: 
                        z = z.parent 
                        self.right_rotate(z)
                    z.parent.color = Color.BLACK 
                    z.parent.parent.color = Color.RED 
                    self.left_rotate(z.parent.parent)
                    
        if self.root_node.color == Color.RED: 
            self.root_node.color = Color.BLACK


    def rb_remove_fixup(self, x: rb_node) ->None: 
        while x is not self.root_node and x.color == Color.BLACK: 
            if x == x.parent.left: 
                w = x.parent.right
                if w.color == Color.RED: 
                    w.color = Color.BLACK
                    x.parent.color = Color.RED 
                    self.left_rotate(x.parent)
                    w = x.parent.right 
                if w is rb_tree.NIL: 
                    x = x.parent 
                    continue 
                if w.left.color == Color.BLACK and w.right.color == Color.BLACK: 
                    w.color = Color.RED 
                    x = x.parent 
                else: 
                    if w.right.color == Color.BLACK: 
                        w.left.color = Color.BLACK 
                        w.color = Color.RED 
                        self.right_rotate(w)
                        w = x.parent.right 
                    w.color = x.parent.color 
                    x.parent.color = Color.BLACK 
                    w.right.color = Color.BLACK 
                    self.left_rotate(x.parent)
                    x = self.root_node
            else: 
                w = x.parent.left 
                if w.color == Color.RED: 
                    w.color = Color.BLACK 
                    x.parent.color = Color.RED 
                    self.right_rotate(x.parent)
                    w = x.parent.right 
                if w is rb_tree.NIL: 
                    x = x.parent 
                    continue 
                if w.left.color == Color.BLACK and w.right.color == Color.BLACK: 
                    w.color = Color.RED 
                    x = x.parent 
                else: 
                    if w.left.color == Color.BLACK:
                        w.right.color = Color.BLACK 
                        w.color = Color.RED 
                        self.left_rotate(w)
                        w = x.parent.left
                    w.color = x.parent.color 
                    x.parent.color = Color.BLACK 
                    w.left.color = Color.BLACK 
                    self.right_rotate(x.parent)
                    x = self.root_node
        x.color = Color.BLACK


    def insert(self, new_data: int) -> None: 
        z = rb_node(data=new_data, NIL=rb_tree.NIL)
       
        if self.root_node is None: 
            self.root_node = z 
            self.rb_insert_fixup(z) 
            self.nr_elements += 1 
            return None 
        
        run = self.root_node 
        while True: 
            if new_data <= run.data: 
                if run.left is rb_tree.NIL: 
                    run.left = z 
                    z.parent = run 
                    break 
                else: 
                    run = run.left 
            else: 
                if run.right is rb_tree.NIL: 
                    run.right = z 
                    z.parent = run 
                    break 
                else: 
                    run = run.right 
        self.rb_insert_fixup(z)
        self.nr_elements += 1 
        return None 
    

    def remove(self, n: int) -> None: 
        z = rb_tree.search_node(self.root_node, n)
        if z is None: 
            raise ValueError(f"data to be removed, {n}, does not exist")
        y = z 
        y_original_color = y.color 
        if z.left is rb_tree.NIL: 
            x = z.right 
            self.rb_transplant(z, z.right)
        elif z.right is rb_tree.NIL: 
            x = z.left 
            self.rb_transplant(z, z.left)
        else: 
            y = z.right 
            while y.left is not rb_tree.NIL: 
                y = y.left
            y_original_color = y.color 
            x = y.right 
            if y.parent is z: 
                x.parent = y 
            else: 
                self.rb_transplant(y, y.right)
                y.right = z.right 
                y.right.parent = y 
            self.rb_transplant(z, y)
            y.left = z.left 
            y.left.parent = y 
            y.color = z.color 
        if y_original_color == Color.BLACK and x is not rb_tree.NIL: 
            self.rb_remove_fixup(x)
        self.nr_elements -= 1 


    def find(self, n: int) -> bool: 
        node = rb_tree.search_node(self.root_node, n)
        return node is not rb_tree.NIL


    def inorder(self): 
        print(f'[START]<->', end='')
        rb_tree._inorder(self.root_node)
        print(f'[END]')


    def max_allowed_height(self): 
        from math import floor, log2 
        return floor(2 * log2(self.nr_elements + 1))
    

    def height(self):
        if self.root_node is None: 
            return 0 
        return rb_tree._height(self.root_node)

    
    def __len__(self): 
        return self.nr_elements


if __name__ == '__main__': 
    from random import randint 
    from math import floor, log2
    from sys import argv 
    assert len(argv) == 2, "Usage:script_name nr_elements"
    rbt = rb_tree()
    N = int(argv[1])
    data = [randint(1, N*10) for i in range(N)]
    for z in data: 
        rbt.insert(z)
        print(f"Current Height:{rbt.height()}, Max allowed height:{rbt.max_allowed_height()}") # comment while testing 
                                                                                               # for large N 
    rbt.inorder() # comment while testing for large N
    print("nr_elements:", len(rbt))
    print("Max Allowed Height:", 2 * floor(log2(N + 1)))
    print("Height:", rbt.height())
    print("-----------------------------------------------")
    print("INSERT TESTING OVER")

    n_removed = 0 
    for z in data: 
        n_removed += 1  
        rbt.remove(z) 
        remaining_N = N - n_removed
        print("Remaning Nodes:", remaining_N) 
        #print("Current Height:", rbt.height())
        print("Max Allowed Height:", 2 * floor(log2(remaining_N + 1)))
        print("-----------------------------------------------")
    print("REMOVE TESTING OVER")
    
