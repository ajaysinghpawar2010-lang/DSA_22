from time import time

L = list(range(59))

def search(L: list, s_data: int) -> bool:
    for x in L:
        if x == s_data:
            return True
    return False

t_start = time()
search(L, 45)
t_end = time()
print(t_end-t_start)
