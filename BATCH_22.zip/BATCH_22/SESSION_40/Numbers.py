class evens_iterator: 
    def __init__(self, G): 
        self.G = G 

    
    def __iter__(self): 
        return self 

    
    def __next__(self): 
        return self.G.__next__() 


class odds_iterator: 
    def __init__(self, G): 
        self.G = G 

    
    def __iter__(self): 
        return self 

    
    def __next__(self): 
        return self.G.__next__()

class Numbers: 
    def __init__(self, N: int): 
        if type(N) != int: raise TypeError 
        if N <= 0: raise ValueError 
        self.L = list(range(1, N+1))

    
    def evens(self): 
        def get_generator(self): 
            for x in self.L: 
                if x % 2 == 0: 
                    yield x 
        return evens_iterator(get_generator(self))
    

    def odds(self): 
        def get_generator(self): 
            for y in self.L: 
                if y % 2 == 1: 
                    yield y 
        return odds_iterator(get_generator(self))


    def show(self): 
        print(self.L)


def main(): 
    N = Numbers(10)
    N.show() 

    print("all evens")
    for x in N.evens(): 
        print(x) 

    print("all odds")
    for y in N.odds(): 
        print(y)


main()