class vowels_iterator: 
    def __init__(self, G): 
        self.G = G 


    def __next__(self): 
        return self.G.__next__()


    def __iter__(self): 
        return self 

class consonents_iterator: 
    def __init__(self, G): 
        self.G = G 


    def __next__(self): 
        return self.G.__next__()


    def __iter__(self): 
        return self 
    

class Word: 
    def __init__(self, s: str): 
        if type(s) != str: raise TypeError 
        if not s.isidentifier(): raise ValueError 
        self.s = s 


    def vowels(self): 
        def get_generator(s: str): 
            for c in s: 
                if c in 'aeiou': 
                    yield c
        return vowels_iterator(get_generator(self.s.lower()))
    

    def consonents(self): 
        def get_generator(s: str): 
            for c in s: 
                if c not in 'aeiou_': 
                    yield c
        return consonents_iterator(get_generator(self.s.lower()))


    def __str__(self): 
        return self.s 
    

def main(): 
    W = Word("CORECODE_PROGRAMMING_ACADEMY")
    print("W:", W)
    print("all vowels:")
    for c in W.vowels(): 
        print(c)
    print("all consonents:")
    for c in W.consonents(): 
        print(c)


main() 