#include <iostream>
#include <cstdlib> 
#include <cmath> 

int main(void){
    double inf = INFINITY;
    double d; 

    std::cout << "Enter any large fractional number:"; 
    std::cin >> d; 

    if(d < inf)
        std::cout << d << " is less than " << inf << std::endl; 

    bool b = std::isinf(inf);
    if(b == true)
        std::cout << "variable inf does contain infinity" << std::endl; 

    return 0; 
}

bool get_int(int** pp){
    int* ptr = (int*)malloc(sizeof(int)); 
    if(0 == ptr){
        *pp = 0; 
        return false; 
    }

    *pp = ptr; 
    return true; 
}