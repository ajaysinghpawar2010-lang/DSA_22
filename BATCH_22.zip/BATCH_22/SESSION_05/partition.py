"""
@author: Yogeshwar Shukla
@date: 27th April 2024 
@goal: to implement and test the partition procedure 
        which is a main helper procedure in the quick sort 
        algorithm 
"""

import sys 

def partition(L: [int], p: int, r: int) -> int: 
    """
    @input: 
        @L: non-empty list of integers 
        @p: integer index in L 
        @r: integer index in L 
    @output: 
        index q satisfying @postcondition 
    @precondition: 
        1) 0 <= p < r < len(L)
    @postcondition:
        1)  Element at L[r] should be moved to index q 
            between [p, r] and rest of the elements 
            should be re-arranged (permuted) such that 
        
            i) all elements from L[p...q-1] are less than 
            or equal to L[q]
            ii) all elements from L[q+1...r] are greater 
            than L[q]
    """ 
    pivot = L[r]
    i = p - 1 
    for j in range(p, r): 
        if L[j] <= pivot: 
            i = i + 1 
            L[i], L[j] = L[j], L[i]
    L[i+1], L[r] = L[r] , L[i+1]
    return (i+1)

def main(): 
    L = [
            100, 200, 300, 
            25, 60, 63, 23, 40, 45, 70, 30, 55, 50, 
            1000, 458, -328
        ]
    
    p = L.index(25) 
    r = L.index(50) 

    q = partition(L, p, r)

    print(f'L[{q}]:{L[q]}')
    print(f'L[{p}:{q}]:{L[p:q]}')
    print(f'L[{q+1}:{r+1}]:{L[q+1:r+1]}')

    sys.exit(0) 
    
main()
