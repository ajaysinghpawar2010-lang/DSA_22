print("start")

def g():
    a = 10
    b = 20
    c = a+b
    return c

def f():
    print("Hello")
    g()
    L = [10, 20, 30, 40]
    n = len(L) 

f()

def test_function():
    print("In test_function()")
    test_function() 

test_function()

