def T(n:int) -> float:
    return 7.2 * (n ** 2) - 8 * n + 5  


def f1(n): 
    return n**4

c = 1
No = None 
greater_yet = False 
for n in range(1, 101): 
    N1 = T(n)
    N2 = c * f1(n)
    print(f"n:{n}, T(n):{N1}, c*f1(n): {N2}")
    if N2 > N1 and greater_yet == False: 
        greater_yet = True 
        No = n 

print(f"c=={c}, No=={No}")