def T(n: int) -> float: 
    return 8.3 * (n**3) + (5.2) * (n**2) + 12 * n + 2.4 


def f(n): 
    return n ** 2 

c = 10000000
n = 1 
while True: 
    N1 = T(n)
    N2 = c * f(n)
    if N1 > N2: 
        s = "T(n)"
    else: 
        s = "c*f(n)"
    print(f"n:{n}, T(n):{N1}, c*f(n):{N2}, greater:{s}")
    if N1 > N2: 
        print(n)
        print("STOP")
        break 
    n = n + 1 

