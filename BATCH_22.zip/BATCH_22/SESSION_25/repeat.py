def test(z): 
    if z.parent is None: 
        print("z is a root node")
    elif z is z.parent.left: 
        print("z is a left child of its parent")
    else: 
        print("z is a right child of its parent")

def test(z): 
    if z.parent is None: 
        print("z is a root node")
    elif z is z.parent.left: 
        print("z is a left child its parent")
    else: 
        print("z is a right child of its parent")


def test(z): 
    if z.parent is None: 
        print("z is a root node")
    elif z is z.parent.left: 
        print("z is a left child is its parent")
    else: 
        print("z is a right child of its parent")

#---------------------------------------------------------------


class bst_node: 
    def __init__(self, data): 
        self.data = data 
        self.left = None 
        self.right = None 
        self.parent = None 

class bst: 
    def __init__(self): 
        self.root_node = None 
        self.nr_elements = 0 

    def remove(self, r_data): 
        z = bst.search_node(self.root_node, r_data)
        if z is None: 
            raise ValueError("cannot find data to be removed")

        # case 1 
        if z.left is None: 
            if z.parent is None: 
                self.root_node = z.right 
            elif z is z.parent.left: 
                z.parent.left = z.right 
            else: 
                z.parent.right = z.right 
            
            if z.right is not None: 
                z.right.parent = z.parents

        elif z.right is None: 
            if z.parent is None: 
                self.root_node = z.left 
            elif z is z.parent.left: 
                z.parent.left = z.left 
            else: 
                z.parent.right = z.left 

            z.left.parent = z.parent             

        else: 
            pass 
