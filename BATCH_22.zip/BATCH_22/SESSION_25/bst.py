import sys 

class bst_node: 
    def __init__(self, data: any): 
        self.data = data 
        self.left = None 
        self.right = None 
        self.parent = None 


class bst: 
    def __init__(self): 
        self.root_node = bst_node(None)
        self.nr_elements = 0 


    @staticmethod 
    def search_node(root_node: bst_node, data: any) -> bst_node: 
        run = root_node 
        while run is not None: 
            if run.data == data: 
                return run 
            elif data <= run.data: 
                run = run.left 
            else: 
                run = run.right 
        return None 
    
    
    def remove(self, data: any) -> None: 
        z = bst.search_node(self.root_node, data)
        if z is None: 
            raise ValueError("Data to be removed not found in BST")
        
        # case 1: left sub-tree of a node to be delete is empty 
        # right subtree may or may not be empty 
        if z.left is None: 





