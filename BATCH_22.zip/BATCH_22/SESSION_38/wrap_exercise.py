class Int: 
    def __init__(self, n: int): 
        self.n = n 
        

    def __str__(self): 
        return str(self.n) 


class CPA_int: 
    def __init__(self, N: Int): 
        self.N = N 


    def __str__(self): 
        return str(self.N)


def main(): 
    I = Int(100)
    CI = CPA_int(I)
    print(CI)

    print("type(CI):", type(CI))
    print("type(CI.N)", type(CI.N))
    print("type(CI.N.n):", type(CI.N.n))


main() 