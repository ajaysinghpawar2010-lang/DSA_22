import sys 

sys.setrecursionlimit(100000000)

cnt = 0 
def f(): 
    global cnt 
    cnt += 1 
    print(cnt) 
    f() 

f() 

