#include <stdxcept> 

class empty_tree_error : public std::runtime_error {
    public: 
        empty_tree_error(const char* msg) : std::runtime_error(msg){
        }
};