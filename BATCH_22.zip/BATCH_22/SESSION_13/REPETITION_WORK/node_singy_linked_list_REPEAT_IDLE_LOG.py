Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
N = Node(100)
print(N.data, N.next)
100 None
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
N = Node(200)
print(N.data, N.next)
200 None
class Node:
    def __init__(self, new_data):
        self.data= new_data
        self.next= None

        
N = Node(300)
print(N.data, N.next)
300 None
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
N = Node(400)
print(N.data, N.next)
400 None
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
N = Node(500)
print(N.data, N.next)
500 None

class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
N1 = Node(100)
N2 = Node(200)
N3 = Node(300)
N4 = Node(400)
N1.next = N2
N2.next = N3
N3.next = N4

run = N1
while run != None:
    print(run.data)
    run = run.next

    
100
200
300
400
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
class SinglyLinkedlist:
    def __init__(self):
        self.head_node = Node(None)

        
L = SinglyLinkedList()
Traceback (most recent call last):
  File "<pyshell#63>", line 1, in <module>
    L = SinglyLinkedList()
NameError: name 'SinglyLinkedList' is not defined. Did you mean: 'SinglyLinkedlist'?
L = SinglyLinkedList()
Traceback (most recent call last):
  File "<pyshell#64>", line 1, in <module>
    L = SinglyLinkedList()
NameError: name 'SinglyLinkedList' is not defined. Did you mean: 'SinglyLinkedlist'?
class SinglyLinkedList:
    def __init__(self):
        self.head_node = Node(None)

        
L = SinglyLinkedList()
L.__dict__
{'head_node': <__main__.Node object at 0x000001C049AC9060>}
L.head_node.__dict__
{'data': None, 'next': None}
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
class SinglyLinkedList:
    def __init__(self):
        self.head_node = Node(None)

        
L = SinglyLinkedList()
L.__dict__
{'head_node': <__main__.Node object at 0x000001C049AC9300>}
L.head_node.__dict__
{'data': None, 'next': None}
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
class SinglyLinkedList:
    def __init__(self):
        self.head_node = Node(None)

        
L = SinglyLinkedList()
L.__dict__
{'head_node': <__main__.Node object at 0x000001C049AC96C0>}
L.head_node.__dict__
{'data': None, 'next': None}
class Node:
    def __init__(self, new_data):
        self.data = new_data

        
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
class SinglyLinkedList:
    def __init__(self):
        self.head_node = Node(None)

        
L = SinglyLinkedList()
L.__dict__
{'head_node': <__main__.Node object at 0x000001C049AC9F30>}
L.head_node.__dict__
{'data': None, 'next': None}
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
class SinglyLinkedList:
    def __init__(self):
        self.head_node = Node(None)

        
L = SinglyLinkedList()
L.__dict__
{'head_node': <__main__.Node object at 0x000001C049ACA0B0>}
L.head_node.__dict__
{'data': None, 'next': None}
class Node:
    def __init__(self, new_data):
        self.data = new_data
        self.next = None

        
class SinglyLinkedList:
    def __init__(self):
        self.head_node = Node(None)

        
L = SinglyLinkedList()
L.__dict__
{'head_node': <__main__.Node object at 0x000001C049ACA230>}
L.head_node.__dict__
{'data': None, 'next': None}
