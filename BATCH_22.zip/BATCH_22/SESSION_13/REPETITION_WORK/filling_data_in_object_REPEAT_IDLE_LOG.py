Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
class Test:
    def __init__(self):
        pass

    
t = Test()
t.__dict__
{}
class Test:
    def __init__(self):
        pass

    
t = Test()
t.__dict__
{}
class Test:
    def __init__(self):
        pass

    
t = Test()
t.__dict__
{}
class Test:
    def __init__(self):
        self.a = 10
        self.b = True
        self.c = 3.14

        
t = Test()
t.__dict__
{'a': 10, 'b': True, 'c': 3.14}
# object_name.new_attr_name = val # attr_name:value
class Test:
    def __init__(self):
        self.a = 10
        self.b = True
        self.c = 3.14

        
t = Test()
t.__dict__
{'a': 10, 'b': True, 'c': 3.14}
class Test:
    def __init__(self):
        self.a = 10
        self.b = True
        self.c = 3.14

        
t = Test()
t.__dict__
{'a': 10, 'b': True, 'c': 3.14}
class Test:
    def __init__(self, init_a, init_b, init_c):
        self.a = init_a
        self.b = init_b
        self.c = init_c

        
t = Test(100, True, 350)
t.__dict__
{'a': 100, 'b': True, 'c': 350}
class Test:
    def -__init__(self, init_a, init_b, init_c):
        
SyntaxError: invalid syntax
class Test:
    def __init__(self, init_a, init_b, init_c):
        self.a = init_a
        self.b = init_b
        self.c = init_c

        
t = Test(100, True, 200)
t.__dict__
{'a': 100, 'b': True, 'c': 200}
class Test:
    def __init__(self, init_a, init_b, init_c):
        self.a = init_a
        self.b = init_b
        self.c = init_c

        
t = Test()
Traceback (most recent call last):
  File "<pyshell#67>", line 1, in <module>
    t = Test()
TypeError: Test.__init__() missing 3 required positional arguments: 'init_a', 'init_b', and 'init_c'
t
t = Test(100, 200, 300)
t.__dict__
{'a': 100, 'b': 200, 'c': 300}
