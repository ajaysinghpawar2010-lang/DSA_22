import sys 

def insertion_sort(L: list[int]) -> None: 
    if type(L) != list: 
        raise TypeError("L must be a list object")
    if len(L) == 0: 
        raise ValueError("L must a non-empty")
    
    for j in range(1, len(L)): 
        key = L[j]
        i = j - 1 
        while i > -1 and L[i] > key: 
            L[i+1] = L[i]
            i = i - 1
        L[i + 1] = key 

def main(): 
    in_file_path = r"data\in.txt"
    op_file_path = r"data\in.txt"

    try: 
        f_input_handle = open(in_file_path, "r")

        master_list = [] 
        for line in f_input_handle: 
            L = [] 
            line = line.strip()
            L = line.split() 
            for i in range(len(L)): 
                L[i] = int(L[i])
            master_list.extend(L)
        f_input_handle.close() 
        
        insertion_sort(master_list)
        
        f_output_handle = open(op_file_path, "w")
        for num in master_list: 
            print(num, end=' ', file=f_output_handle)
        print('\n', file=f_output_handle)
        f_output_handle.close() 
    
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info()
        print(exc_name, exc_data) 
        sys.exit(-1) 

main()