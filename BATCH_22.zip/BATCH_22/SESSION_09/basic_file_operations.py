"""
@author: Yogeshwar Shukla 
@goal:  to implement basic file handling operations 
        using high level file handling interface 
        provided by Python 
"""

import sys 

def main(): 
    # C:\Users\yogesh\OneDrive\CPA\DS_ALG\BATCH_CODES\BATCH_22\SESSION_09\abc.txt 
    file_path = r"data\abc.txt"

    # Create a new file abc.txt or open existing file abc.txt by truncating data in it 
    # write 5 numbers of 5 liens and close the file 
    try: 
        f_handle = open(file_path, "w")
        L = [500, 300, 200, 100, 400]
        for x in L: 
            print(x, file=f_handle)
        f_handle.close()
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info()
        print(exc_name, exc_data) 
        sys.exit(-1) 

    # reopen the file with "read" intent 

    try: 
        f_handle = open(file_path, "r")
        for line in f_handle: 
            line = line.strip() 
            print(line)
        f_handle.close() 
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info()
        print(exc_name, exc_data) 
        sys.exit(-1) 

    sys.exit(0)

main()

"""
import sys 
import traceback 

try: 
    f_handle = open(file_path, "w")
except: 
    exc_name, exc_data, exc_tb = sys.exc_info()
    print(exc_name, exc_data) 
    sys.exit(-1) 
    # traceback.print_tb(exc_tb)
    
"""