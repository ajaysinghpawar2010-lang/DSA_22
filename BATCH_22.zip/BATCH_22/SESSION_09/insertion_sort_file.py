import sys 

def insertion_sort(L: list[int]) -> None: 
    if type(L) != list: 
        raise TypeError("L must be a list object")
    if len(L) == 0: 
        raise ValueError("L must a non-empty")
    
    for j in range(1, len(L)): 
        key = L[j]
        i = j - 1 
        while i > -1 and L[i] > key: 
            L[i+1] = L[i]
            i = i - 1
        L[i + 1] = key 

def main(): 
    in_file_path = r"data\abc.txt"
    op_file_path = r"data\pqr.txt"

    try: 
        f_input_handle = open(in_file_path, "r")

        L = [] 
        for line in f_input_handle: 
            line = line.strip()
            L.append(int(line)) # refer note 1 
        f_input_handle.close() 
        
        insertion_sort(L)
        
        f_output_handle = open(op_file_path, "w")
        for num in L: 
            print(num, file=f_output_handle)
        f_output_handle.close() 
    
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info()
        print(exc_name, exc_data) 
        sys.exit(-1) 

main()

"""
node 1: 
s = "455" 
n = int(s) 

int()   ->  creates a new object of class int 
int(s)  ->  string s is sent as initialization object 
        ->  constructor of int type does format conversion 
            from string representation of 455 into integer 
            representation of 455 

            if characters of string does not form valid integer 
            then int(s) throws a value error exception 

            it will be handled by generic exception block that we 
            have written 



"""