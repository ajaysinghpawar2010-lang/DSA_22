def gexcept(): 
    import sys 
    exc_name, exc_data, _ = sys.exc_info() 
    print(exc_name.__name__, exc_data, sep=':')


def intersection(L1, L2): 
    lst = [] 
    for i in range(len(L1)): 
        if L1[i] in L2 and L1[i] not in lst: 
            lst.append(L1[i])
    return (lst)

L1 = [10, 20, 30, 40, 50]
L2 = [40, 50, 60, 70, 80]

result = intersection(L1, L2)
print(result)

try: 
    result = intersection(10, 20)
except: 
    gexcept()
#-----------------------------------------------------
def intersection_1(L1, L2): 
    if type(L1) != list: 
        raise TypeError("Bad type for L1")
    if type(L2) != list: 
        raise TypeError("Bad type for L2")
    lst = [] 
    for i in range(len(L1)): 
        if L1[i] in L2 and L1[i] not in lst: 
            lst.append(L1[i])
    return (lst)
#-----------------------------------------------------
ret = intersection((100, 200, 300), (300, 200, 400, 500, 600))
print("ret:", ret)

ret = intersection("Hello", "World")
print("ret:", ret)
#-----------------------------------------------------
try: 
    ret = intersection({100, 200, 300, 400}, {300, 400, 500, 600})
    print("ret:", ret)
except: 
    gexcept() 
#-----------------------------------------------------
def intersection_2(seq_1, seq_2): 
    required_methods_for_seq_1 = ['__len__', '__getitem__']
    required_methods_for_seq_2 = ['__contains__']

    for method_name in required_methods_for_seq_1: 
        if method_name not in dir(type(seq_1)): 
            raise TypeError(f"type(seq_1):{type(seq_1)} not compatible")
    for method_name in required_methods_for_seq_2: 
        if method_name not in dir(type(seq_2)): 
            raise TypeError(f"type(seq_2):{type(seq_2)} not compatible")
    lst = [] 
    for i in range(len(seq_1)): 
        if seq_1[i] in seq_2 and seq_1[i] not in lst: 
            lst.append(seq_1[i])
    return lst 

ret = intersection_2([100, 200, 300], (100, 200, 500, 600))
print("interseciont_2:ret:", ret)
#---------------------------------------------------------------------------

def intersection_3(iter_1, iter_2): 
    lst = [] 
    for x in iter_1: 
        if x in iter_2 and x not in lst: 
            lst.append(x)
    return lst 

def intersection_3(cntnr_1, cntnr_2): 
    if '__iter__' not in dir(type(cntnr_1)): 
        raise TypeError("cntnr_1 must be an iterable object")
    if '__contains__' not in dir(type(cntnr_2)): 
        raise TypeError("cntnr_2 must support membership testing")
    lst = [] 
    for x in cntnr_1: 
        if x in cntnr_2 and x not in lst: 
            lst.append(x)
    return lst 


    