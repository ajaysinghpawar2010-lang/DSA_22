class List: 
    class Node: 
        def __init__(self, data: int): 
            # Option 1 : Restrict to a single type 
            if type(data) != int: 
                raise TypeError 
            self.data = data 
            self.prev = None 
            self.next = None 

class List: 
    class Node: 
        def __init__(self, data): 
            # Option 2  : DUCK TYPING
            # allow a family of data types 
            # based on what can be done with their objects  
            required_methods = [] # some method names in string format
            for method_name in required_methods:  
                if method_name not in dir(type(data)): 
                    raise TypeError 
            self.data = data 
            self.prev = None 
            self.next = None 


class List: 
    class Node: 
        def __init__(self, data): 
            # Option 3 : Multiple allowed types 
            allowed_types = [] # some known types 
            if type(data) not in allowed_types: 
                raise TypeError 
            self.data = data 
            self.prev = None 
            self.next = None 