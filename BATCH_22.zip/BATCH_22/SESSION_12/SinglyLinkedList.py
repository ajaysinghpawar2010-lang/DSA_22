"""
@author: Yogeshwar Shukla 
@date: 18th May 2024 
@goal: To implement and test SinglyLinkedList 
"""

# SERVER SIDE 

class Node: 
    def __init__(self, data: any):
        self.data = data 
        self.next = None 


class SinglyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)


    def insert_start(self, new_data: any) -> bool: 
        pass 


    def insert_end(self, new_data: any) -> bool: 
        pass


    def insert_after(self, existing_data:  any, new_data: any) -> bool: 
        pass


    def insert_before(self, existing_data: any, new_data: any) -> bool: 
        pass


    def get_start(self) -> any: 
        pass 


    def get_end(self) -> any: 
        pass 


    def pop_start(self) -> any: 
        pass 


    def pop_end(self) -> any: 
        pass 


    def remove_start(self) -> None: 
        pass 

    
    def remove_end(self) -> None: 
        pass 


    def remove_data(self, r_data: any) -> any: 
        pass 

    
    def is_empty(self) -> bool: 
        pass 
    

    def get_length(self) -> int: 
        pass  
    
    
    def show(self, msg: str) -> None: 
        pass 


# CLIENT SIDE 

L = SinglyLinkedList()
