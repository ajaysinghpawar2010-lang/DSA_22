"""
1) Singly Linked List 
2) Singly Circular Linked List 
3) Doubly Linked List 
4) Doubly Circular Linked List 

In first three lists, we do not have direct access 
to the Last Node object. 

[
    Definition: The Last Node Object: If the linked list is empty 
    then head node is the last Node Object. 

    If the linked list is non-empty the Node object containing 
    data whose 'next' attribute is None (or head_node)
    is the last Node object

]

Therefore, we must write a navigation logic to reach 
to the last node with data. 

run = self.head_node 
while run.next is not None: 
    run = run.next 

run.next == NONE 
run == last node 

When we want to visit every node with data 

run = self.head_node.next
while run is not None: 

    run = run.next 
"""