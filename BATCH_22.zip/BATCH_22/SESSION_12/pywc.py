"""
@author: Yogeshwar 
@date: 19th May 2024 
@goal: To implement wc command in the coreutils package of the Linux OS 
@commandline: 

# python pywc.py file1 
OR 
# python pywc.py file1 file2 .... filen 

@output: 

for command line 1 

lines words chars file1 
#------------------------------
for command line 2 

L1  W1  C1  F1 
L2  W2  C2  F2 
.
.
.
Ln  Wn  Cn  Fn 
TL  TW  TC  total 
"""

import sys 


EXIT_SUCCESS = 0 
EXIT_FAILURE = -1 


def main(argc: int, argv: list[str]) -> None: 

    if argc < 2: 
        print(f'UsageError:Correct Usage:{argv[0]} file(s)')
        sys.exit(EXIT_FAILURE)

    for file_path in argv[1:]: 
        print(file_path)

    sys.exit(EXIT_SUCCESS) 


main(len(sys.argv), sys.argv)
