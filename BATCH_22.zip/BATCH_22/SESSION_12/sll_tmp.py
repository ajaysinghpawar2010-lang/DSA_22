from sys import exc_info 

class Node: 
    def __init__(self, data): 
        self.data = data 
        self.next = None 

class SinglyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)

    def insert_start(self, new_data): 
        new_node = Node(new_data)
        new_node.next = self.head_node.next 
        self.head_node.next = new_node 


    def insert_end(self, new_data): 
        new_node = Node(new_data)
        
        run = self.head_node
        while run.next != None: 
            run = run.next 
        
        new_node.next = run.next 
        run.next = new_node 

    def insert_after(self, e_data, new_data): 
        run = self.head_node.next 
        while run is not None: 
            if run.data == e_data: 
                break 
            run = run.next
        else: 
            raise ValueError(f'{e_data} is not found')
        
        new_node = Node(new_data) 
        new_node.next = run.next 
        run.next = new_node 


    def show(self): 
        print("[START]->", end='')
        
        run = self.head_node.next 
        while run is not None: 
            print(f"[{run.data}]->", end='')
            run = run.next 

        print("[END]")

L = SinglyLinkedList()

L.show() # [START]->[END]

L.insert_end(10)
L.insert_end(20)
L.insert_end(30)
L.insert_end(40)

L.show() # [START]->[10]->[20]->[30]->[40]->[END]

L.insert_start(100)
L.insert_start(200)
L.insert_start(300)

L.show() # [START]->[300]->[200]->[100]->[10]->[20]->[30]->[40]->[END]

L.insert_after(100, 500)
L.insert_after(40, 50)

L.show() 

try: 
    L.insert_after(-450, 1000)
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)
    
n = L.length() 
print(f"length(L)=={n}")

ret = L.find(500) 
if ret == True: 
    print(f'500 is present in list')

ret = L.find(-1)
if ret == False: 
    print("-1 is not present in list")