import sys 

print(sys.argv) # list of strings 

for i in range(1, len(sys.argv)): 
    print(sys.argv[i])