"""
Consider class C and a method test() implemented in it. 

class C: 
    def test(): 
        pass 
        
Python requires us to write at least one formal parameter named 
self for method test. 
Why? 

Because the test() function is implemented inside class C
and therefore it must be invoked using object of class C
shown as follows: 

objC1 = C() 
objC2 = C() 

objC1.test() 
objC2.test() 

As per OOP theory, a method implemented inside a class is written to 
manipulate object of that class. 

Therefore, any OOP language wants to make object  available to such functions 
meaning : 

objC1.test() -> OOP language would want objC1 to be avaialable for test() 

Therefore, an object used to invoke method implemented inside class of that object 
is called as 'CALLING OBJECT' 

all OOP languages pass the CALLING OBJECT to the method. 
And therefore, a method must reserve its first formal parameter for receive 
the CALLING OBJECT. 

In many languages this is achieved by keeping invisible 'this' pointer or reference 
variable. 

In Python, a programmer is asked to keep one formal parameter reserved for it. 
Python programmer does so by keeping name of the first formal parameter of 
the method inside class as 'self' (by convention. self is not a keyword)

Sometimes, you do want to implement a method inside class (because it is related to 
class in some way), and you do want to invoke that method using object name 
but you do not require an access to CALLING OBJECT. Such methods are known as 
static methods. 

Python does not have the keyword 'static' to mark such methods as such. 

But it has a staticmethod decorators which when applied to class methods 
result in the suppression of passing of CALLING OBJECT. 
"""