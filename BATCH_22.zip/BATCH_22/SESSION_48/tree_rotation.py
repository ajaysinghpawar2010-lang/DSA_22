SUCCESS = 1 

class bst_node: 
    def __init__(self, data: int): 
        self.data = data 
        self.left = None 
        self.right = None 
        self.parent = None 

class bst: 
    def __init__(self): 
        self.root_node = None 
        self.nr_elements = 0 


    @staticmethod 
    def inorder_r(root_node: bst_node) -> None: 
        if root_node is not None: 
            bst.inorder_r(root_node.left)
            print(f"[{root_node.data}]<->", end='')
            bst.inorder_r(root_node.right)


    @staticmethod 
    def postorder_r(root_node: bst_node) -> None: 
        if root_node is not None: 
            bst.postorder_r(root_node.left)
            bst.postorder_r(root_node.right)
            print(f"[{root_node.data}]<->", end='')
            

    @staticmethod 
    def search_node(root_node: bst_node, search_data: int) -> bst_node: 
        run = root_node 
        while run is not None: 
            if run.data == search_data: 
                return run 
            elif search_data < run.data: 
                run = run.left 
            else: 
                run = run.right 
        return run 
    

    def _left_rotate(self, z: bst_node): 
        y = z.right 
        z.right = y.left 
        if y.left.parent is not None: 
            y.left.parent = z 
        y.parent = z.parent
        if z.parent is None: 
            self.root_node = y 
        elif z == z.parent.left: 
            z.parent.left = y 
        else: 
            z.parent.right = y 
        y.left = z 
        z.parent = y 

 
    def _right_rotate(self, z: bst_node): 
        y = z.left 
        z.left = y.right 
        if y.right is not None: 
            y.right.parent = z 
        y.parent = z.parent
        if z.parent is None: 
            self.root_node = y 
        elif z == z.parent.left: 
            z.parent.left = y 
        else: 
            z.parent.right = y 
        y.right = z 
        z.parent = y 


    def insert(self, new_data) -> int: 
        new_node = bst_node(new_data)

        if self.root_node is None: 
            self.root_node = new_node 
            self.nr_elements += 1 
            return SUCCESS 
        
        self.nr_elements += 1
        run = self.root_node 
        while True: 
            if new_data <= run.data: 
                if run.left is None: 
                    run.left = new_node 
                    new_node.parent = run 
                    return SUCCESS 
                else: 
                    run = run.left 
            else: 
                if run.right is None: 
                    run.right = new_node 
                    new_node.parent = run 
                    return SUCCESS 
                else: 
                    run = run.right 
       

    def inorder(self): 
        print("[START]<->", end='')
        bst.inorder_r(self.root_node)
        print("[END]")


    def postorder(self): 
        print("[START]<->", end='')
        bst.postorder_r(self.root_node)
        print("[END]")


    def left_rotate(self, data: int): 
        z = bst.search_node(self.root_node, data)
        if z is None: 
            raise ValueError("left_rotate:invalid data")
        if z.right is None: 
            raise ValueError("left_rotate cannot be taken if right subtree is empty")
        self._left_rotate(z)

    
    def right_rotate(self, data: int): 
        z = bst.search_node(self.root_node, data)
        if z is None: 
            raise ValueError("right_rotate:invalid data")
        if z.left is None: 
            raise ValueError("right_rotate cannot be taken if left subtree is empty")
        self._right_rotate(z)


    def get_nr_elements(self) -> int: 
        return self.nr_elements

if __name__ == '__main__': 
    data = [    
                570, 684, 509, 440, 117, 582, 
                211, 318, 967, 416, 347, 430, 
                586, 818, 850, 311, 996, 162
            ]
    
    print(data)
    
    T = bst() 
    
    for d in data: 
        T.insert(d)
    print(f"#T:{T.get_nr_elements()}")
    
    print("INORDER:FOR CONSISTENCY CHECK")
    T.inorder() 

    print("POSTORDER:BEFORE LEFT ROTATE:")
    T.postorder()
   
    T.left_rotate(117)
    print("POST ORDER AFTER LEFT ROTATE:")
    T.postorder()

    T.right_rotate(440)
    print("POST ORDER AFTER RIGHT ROTATE:")
    T.postorder()