def bin_search(
        L: list[int],
        search_data: int, 
        start_index: int, 
        end_index: int 
    ) -> bool: 

    if start_index > end_index: 
        return False 

    mid_index = (start_index + end_index) // 2 

    if search_data == L[mid_index]: 
        return True 
    elif search_data < L[mid_index]: 
        return bin_search(L, search_data, start_index, mid_index-1)
    else: 
        return bin_search(L, search_data, mid_index + 1, end_index)
    
L = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

print("bin_search(L, 95, 0, len(L)-1):", bin_search(L, 95, 0, len(L)-1))
print("bin_search(L, 10, 0, len(L)-1):", bin_search(L, 10, 0, len(L)-1))
print("bin_search(L, 100, 0, len(L)-1):", bin_search(L, 100, 0, len(L)-1))
print("bin_search(L, 70, 0, len(L)-1):", bin_search(L, 70, 0, len(L)-1))