def search_r(L: [int], N: int, s_data: int, i: int) -> bool:
    if i == N:
        return False
    if L[i] == s_data:
        return True
    return search_r(L, N, s_data, i+1)

L = [10, 20, 30, 40, 50, 60]

print("search_r(L, 35):", search_r(L, len(L), 35, 0))
print("search_r(L, 10):", search_r(L, len(L), 10, 0))
print("search_r(L, 60):", search_r(L, len(L), 60, 0))
print("search_r(L, 40):", search_r(L, len(L), 40, 0))
