class TypeName{
    private:
        data member / static data member
        member function / static member function 

    public:
        data member / static data member
        member function / static member function 

        CONSTRUCTOR
        DESTRUCTOR
        COPY CONSTRUCTOR
        COPY ASSIGNMENT OPERATOR
        MOVE CONSTRUCTOR
        MOVE ASSIGNMENT OPERATOR

        OPERATOR OVERLOADING

        VIRTUAL FUNCTIONS
    protected:
        data member / static data member
        member function / static member function
}; 
