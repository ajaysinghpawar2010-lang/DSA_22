def prn(L: [int], N: int, i: int) -> None:
    if i == N:
        return None
    prn(L, N, i+1)
    print(f'L[{i}]:{L[i]}')
    
    return None 

L = [10, 20, 30, 40, 50]
prn(L, len(L), 0)
print("END")
