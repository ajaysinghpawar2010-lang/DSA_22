def f5():
    print("I am the last call")
    return None 
    
def f4():
    print("In f4()")
    f5()
    return None 

def f3():
    print("In f3()")
    f4()
    return None 

def f2():
    print("In f2()")
    f3()
    return None 

def f1():
    print("In f1()")
    f2()
    return None

f1()
print("end")
