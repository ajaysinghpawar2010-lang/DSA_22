
                        return False                if i == N 
        

search(L, N, s, i) =    return True                 if i < N and L[i] == s


                        return search(L, N, s, i+1) if i < N and L[i] != s 
