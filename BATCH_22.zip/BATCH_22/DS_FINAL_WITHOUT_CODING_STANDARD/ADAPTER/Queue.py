import sys 
import List 


class Queue: 
    def __init__(self): 
        self.L = List.List() 


    def enqueue(self, data: any) -> None: 
        self.L.insert_end(data)

    
    def peek(self) -> any: 
        try: 
            data = self.L.get_start() 
            return data 
        except: 
            raise ValueError("Cannot peek() into the empty Queue")
        

    def dequeue(self) -> any: 
        try: 
            data = self.L.pop_start() 
            return data 
        except: 
            raise ValueError("Cannot dequeue() the empty Queue")
        
    
    def empty(self) -> bool: 
        return self.L.empty() 
    

if __name__ == '__main__': 
    Q = Queue() 

    if Q.empty(): 
        print("Q is empty")

    
    try: 
        data = Q.peek()
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info()
        print(exc_name, exc_data, sep=':')

    
    try: 
        data = Q.dequeue() 
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info()
        print(exc_name, exc_data, sep=':')

    
    for i in range(8): 
        Q.enqueue((i+1) * 100)

    
    if not Q.empty(): 
        print("Q is not empty")


    while not Q.empty(): 
        data = Q.dequeue() 
        print("DEQUEUED DATA:", data)
    