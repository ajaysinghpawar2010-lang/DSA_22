import sys 
import List 


class Dequeue: 
    def __init__(self): 
        self.L = List.List() 

    
    def enqueue_front(self, data: any) -> None: 
        self.L.insert_start(data)


    def peek_front(self) -> any: 
        try: 
            data = self.L.get_start() 
            return data 
        except: 
            raise ValueError("Cannot peek_front() of the empty dequeue")

    
    def dequeue_front(self) -> any: 
        try: 
            data = self.L.pop_start() 
            return data 
        except: 
            raise ValueError("Cannot dequeue_front() of the empty dequeue")


    def enqueue_back(self, data: any) -> None: 
        self.L.insert_end(data)


    def peek_back(self) -> any: 
        try: 
            data = self.L.get_end() 
            return data 
        except: 
            raise ValueError("Cannot peek_back() of the empty dequeue")
    
    def dequeue_back(self) -> any: 
        try: 
            data = self.L.pop_end() 
            return data 
        except: 
            raise ValueError("Cannot dequeue_back() of the empty dequeue")


    def empty(self) -> any: 
        return self.L.empty() 
    

if __name__  == '__main__': 
    
    dQ = Dequeue() 
    if dQ.empty(): 
        print("dQ is empty")


    try: 
        data = dQ.peek_back() 
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info() 
        print(exc_name, exc_data, sep=':')

    try: 
        data = dQ.dequeue_back() 
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info() 
        print(exc_name, exc_data, sep=':')

    try: 
        data = dQ.peek_front() 
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info() 
        print(exc_name, exc_data, sep=':')

    try: 
        data = dQ.dequeue_front() 
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info() 
        print(exc_name, exc_data, sep=':')


    for i in range(4): 
        dQ.enqueue_front((i+1) * 100)
        dQ.enqueue_back((i+1)*1000)

    
    data = dQ.peek_front() 
    print("FRONT:", data)

    data = dQ.peek_back() 
    print("BACK:", data)


    for i in range(2): 
        data = dQ.dequeue_front() 
        print("FRONT:", data)

    for i in range(2): 
        data = dQ.dequeue_back() 
        print("BACK:", data)

    
    while not dQ.empty(): 
        data = dQ.dequeue_back() 
        print("BACK:", data)

    