import sys 
import List 


class Stack: 
    def __init__(self): 
        self.L = List.List() 


    def push(self, data) -> None: 
        self.L.insert_end(data)


    def top(self)-> any: 
        try: 
            data = self.L.get_end()
            return data
        except: 
            raise ValueError("Cannot top() on empty stack")
        
    
    def pop(self) -> any: 
        try: 
            data = self.L.pop_end() 
            return data 
        except: 
            raise ValueError("Cannot pop() on empty stack")
        
    
    def empty(self) -> bool: 
        return self.L.empty()


if __name__ == '__main__': 
    S = Stack() 
    if S.empty() == True: 
        print("S is empty")
    
    try: 
        data = S.top()
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info()
        print(exc_name, exc_data, sep=':')


    try: 
        data = S.pop() 
    except: 
        exc_name, exc_data, exc_tb = sys.exc_info()
        print(exc_name, exc_data, sep=':') 

    
    for i in range(8): 
        S.push((i+1) * 100)

    
    print(S.top())

    if not S.empty(): 
        print("S is not empty")

    
    while not S.empty(): 
        data = S.pop() 
        print("POPED DATA:", data)

    