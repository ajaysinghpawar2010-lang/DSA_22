"""
Implement Priority Queue of integers 
Implement two functions. 
extract min and extract max 

the extract_min algorithm should remove and return the least valued integer
in the collection and the max should do likewise for the maximum valued integer 

Implement an idea because of which you need not travel the entire List for 
finding min or max ! 
""" 

import random 
import time 

class PriorityQueue: 
    def __init__(self): 
        self.L = [] 

    def enqueue(self, new_data: int) -> None: 
        if type(new_data) != int: 
            raise TypeError("data must be int")
        self.L.append(new_data)
        key = self.L[len(self.L)-1]
        i = len(self.L)-2 
        while i > -1 and self.L[i] > key: 
            self.L[i+1] = self.L[i]
            i = i - 1 
        self.L[i+1] = key 

    def peek_min(self) -> int: 
        if len(self.L) == 0: 
            raise TypeError("Cannot peek_min() into empty queue") 
        return self.L[0]

    def peek_max(self) -> int: 
        if len(self.L) == 0: 
            raise TypeError("cannot peek_max() from empty list")
        return self.L[-1]

    def dequeue_min(self) -> int: 
        if len(self.L) == 0: 
            raise TypeError("Cannot peek_min() into empty queue") 
        return self.L.pop(0)

    def dequeue_max(self) -> int: 
        if len(self.L) == 0: 
            raise TypeError("cannot peek_max() from empty list")
        return self.L.pop() 

if __name__ == '__main__': 
    data = [5, 2, 3, 6, 10, 9, 23, 4, 67, 1, 78, 43] 
    P = PriorityQueue() 
    for x in data: 
        P.enqueue(x)

    random.seed(int(time.time()))
    choice = [random.randint(0, 1) for i in range(len(data))]
    for ch in choice: 
        print(P.L)
        if ch == 1: 
            print("MAX:")
            print(P.dequeue_max())
        elif ch == 0: 
            print("MIN")
            print(P.dequeue_min())
        print("------------------------------")


