from sys import exc_info 

class Node: 
    def __init__(self, data): 
        self.data = data 
        self.next = None 

class SinglyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)


    def insert_start(self, new_data): 
        new_node = Node(new_data)
        new_node.next = self.head_node.next 
        self.head_node.next = new_node 


    def insert_end(self, new_data): 
        new_node = Node(new_data)
        
        run = self.head_node
        while run.next != None: 
            run = run.next 
        
        new_node.next = run.next 
        run.next = new_node 


    def insert_after(self, e_data, new_data): 
        run = self.head_node.next 
        while run is not None: 
            if run.data == e_data: 
                break 
            run = run.next
        else: 
            raise ValueError(f'{e_data} is not found')
        
        new_node = Node(new_data) 
        new_node.next = run.next 
        run.next = new_node 


    def insert_before(self, e_data, new_data): 
        run = self.head_node 
        while run.next is not None: 
            if run.next.data == e_data: 
                break 
            run = run.next 
        else: 
            raise ValueError("Bad existing data")
        new_node = Node(new_data) 
        new_node.next = run.next 
        run.next = new_node 


    def get_start(self) -> any: 
        if self.head_node.next is None: 
            raise ValueError("cannot get the start of the empty list")
        return self.head_node.next.data


    def get_end(self) -> any: 
        if self.head_node.next is None: 
            raise ValueError("cannot get the end of the empty list")
        run = self.head_node 
        while run.next is not None: 
            run = run.next
        return run.data 


    def pop_start(self) -> any: 
        if self.head_node.next is None: 
            raise ValueError("cannot pop the start of the empty list")
        data = self.head_node.next.data 
        self.head_node.next = self.head_node.next.next 
        return data


    def pop_end(self) -> any: 
        if self.head_node.next is None: 
            raise ValueError("cannot pop the end of the empty list") 
        run = self.head_node
        while run.next.next is not None: 
            run = run.next 
        data = run.next.data 
        run.next = run.next.next 
        return data 


    def remove_start(self) -> None: 
        if self.head_node.next is None: 
            raise ValueError("cannot pop the start of the empty list")       
        self.head_node.next = self.head_node.next.next 


    def remove_end(self) -> None: 
        if self.head_node.next is None: 
            raise ValueError("cannot pop the end of the empty list") 
        run = self.head_node
        while run.next.next is not None: 
            run = run.next 
        run.next = run.next.next 

    
    def remove_data(self, r_data: any) -> None: 
        run = self.head_node
        while run.next != None and run.next.data != r_data: 
            run = run.next 
        run.next = run.next.next 

    def find(self, f_data): 
        run = self.head_node.next 
        while run is not None: 
            if run.data == f_data: 
                break 
            run = run.next 
        else: 
            return False 
        return True 

    def length(self): 
        cnt = 0 
        run = self.head_node.next 
        while run is not None: 
            cnt = cnt + 1 
            run = run.next 
        return cnt 

    def show(self, msg=''):
        if type(msg) != str: 
            raise TypeError("msg must be a string")
        if msg != '': 
            print(msg) 

        print("[START]->", end='')
        
        run = self.head_node.next 
        while run is not None: 
            print(f"[{run.data}]->", end='')
            run = run.next 

        print("[END]")

    def concat(self, other): 
        new_list = SinglyLinkedList() 
        run = self.head_node.next 
        while run != None: 
            new_list.insert_end(run.data)
            run = run.next 
        run = other.head_node.next 
        while run != None: 
            new_list.insert_end(run.data)
            run = run.next 
        return new_list 

    
    def append(self, other): 
        # L1.append(L2) # self == L1, other == L2 
        # if L2 is empty, there is nothing to do 
        if other.head_node.next is None: 
            del other.head_node 
            return None 

        # if L2 is not empty then find out the last 
        # node of L1. If L1 is empty the the last node 
        # is head node otherwise last node containing 
        # data object is the last node 
        run = self.head_node 
        while run.next is not None: 
            run = run.next 

        # attach first node with data in L2 with the 
        # 'next' of the last node of L1 
        run.next = other.head_node.next 
        del other.head_node 

    
    def merge(self, other): 
        new_list = SinglyLinkedList() 
        
        run1 = self.head_node.next 
        run2 = other.head_node.next 

        while True: 
            if run1 == None: 
                while run2 != None: 
                    new_list.insert_end(run2.data)
                    run2 = run2.next 
                break 

            if run2 == None: 
                while run1 != None: 
                    new_list.insert_end(run1.data)
                    run1 = run1.next 
                break 

            if run1.data <= run2.data: 
                new_list.insert_end(run1.data)
                run1 = run1.next 
            else: 
                new_list.insert_end(run2.data)
                run2 = run2.next 

        return new_list 
    

    def get_reversed_list(self): 
        new_list = SinglyLinkedList() 
        run = self.head_node.next 
        while run is not None: 
            new_list.insert_start(run.data)
            run = run.next 
        return new_list 

    
    def reverse(self): 
        if self.head_node.next is None or self.head_node.next.next is None: 
            return None 
        
        original_first = self.head_node.next 
        run = self.head_node.next.next 
        while run is not None: 
            run_next = run.next 
            run.next = self.head_node.next 
            self.head_node.next = run 
            run = run_next 
        original_first.next = None 



L = SinglyLinkedList()

L.show() # [START]->[END]

L.insert_end(10)
L.insert_end(20)
L.insert_end(30)
L.insert_end(40)

L.show("After insert_end()") # [START]->[10]->[20]->[30]->[40]->[END]

L.insert_start(100)
L.insert_start(200)
L.insert_start(300)

L.show("After isnert_start():") # [START]->[300]->[200]->[100]->[10]->[20]->[30]->[40]->[END]

L.insert_after(100, 500)
L.insert_after(40, 50)

L.show("After insert_after():") 

try: 
    L.insert_after(-450, 1000)
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

L.insert_before(50, 368)
L.insert_before(100, 491)

L.show("After insert_before():") 

try: 
    L.insert_before(-450, 1000)
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)
    
try: 
    data = L.get_start()   # SinglyLinkedList.get_start(L) 
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

print(f'start_data:{data}')
L.show("after get_start()") 

try: 
    data = L.get_end()     # SinglyLinkedList.get_end(L)
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

print(f'end_data:{data}')
L.show("after get_end()") 

try: 
    data = L.pop_start()   # SinglyLinkedList.pop_start(L)
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

print(f'start_data:{data}')
L.show('after pop_start()') 

try: 
    data = L.pop_end()     # SinglyLinkedList.pop_end(L)
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)
print(f'end_data:{data}')
L.show('after pop_end()') 

try: 
    data = L.remove_start() 
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

L.show('after remove_start()') 

try: 
    data = L.remove_end()  
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

L.show('after remove_end()') 

try: 
    data = L.remove_data(10)  
except: 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name, exc_data)

L.show('after remove_data()') 

n = L.length() 
print(f"length(L)=={n}")

ret = L.find(500) 
if ret == True: 
    print(f'500 is present in list')

ret = L.find(-1)
if ret == False: 
    print("-1 is not present in list")

L.show("L:")
L.reverse() 
L.show("reversed version of L:")
#-----------------------------------------
L1 = SinglyLinkedList() 
L2 = SinglyLinkedList() 

for i in range(5): 
    L1.insert_end(i * 5)
    L2.insert_end(i * 10)

L3 = L1.concat(L2)
L1.show("L1:")
L2.show("L2:")
L3.show("L3:")

L4 = L1.merge(L2)
L4.show("L4:")

L5 = L1.get_reversed_list() 
L5.show("L5: reversed version of L1")

L1.append(L2)
del L2 

L1.show("L1:")