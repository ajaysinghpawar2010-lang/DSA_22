"""
@author: Yogeshwar 
@date: 19th May 2024 
@goal: To implement wc command in the coreutils package of the Linux OS 
@commandline: 

# python pywc.py file1 
OR 
# python pywc.py file1 file2 .... filen 

@output: 

for command line 1 

lines words chars file1 
#------------------------------
for command line 2 

L1  W1  C1  F1 
L2  W2  C2  F2 
.
.
.
Ln  Wn  Cn  Fn 
TL  TW  TC  total 
"""

import sys 


EXIT_SUCCESS = 0 
EXIT_FAILURE = -1 


def get_word_count(s: str) -> int: 
    IN = 1 
    OUT = 2 
    state = OUT 
    w_cnt = 0 
    for c in s: 
        if state == OUT and not c.isspace(): 
            state = IN
            w_cnt += 1 
        elif state == IN and c.isspace(): 
            state = OUT 
    return w_cnt 


def main(argc: int, argv: list[str]) -> None: 

    if argc < 2: 
        print(f'UsageError:Correct Usage:{argv[0]} file(s)')
        sys.exit(EXIT_FAILURE)

    nr_total_chars, nr_total_words, nr_total_lines = 0, 0, 0

    for file_path in argv[1:]: 
        try: 
            per_file_chars, per_file_words, per_file_lines = 0, 0, 0
            f_handle = open(file_path, "r")
            for line in f_handle: 
                per_file_lines += 1 
                per_file_words += get_word_count(line)
                per_file_chars += len(line)
            print(
                per_file_chars, per_file_words, 
                per_file_lines, file_path, sep='\t'
            )
            nr_total_lines += per_file_lines
            nr_total_words += per_file_words 
            nr_total_chars += per_file_chars
            f_handle.close() 
        except: 
            exc_name, exc_data, exc_tb = sys.exc_info() 
            print(exc_name, exc_data, sep=':')
            sys.exit(EXIT_FAILURE)
    
    
    if argc > 2: 
        print(nr_total_chars, nr_total_words, 
              nr_total_lines, "total", sep='\t')


    sys.exit(EXIT_SUCCESS) 


main(len(sys.argv), sys.argv)
