def get_word_count(s: str) -> int: 
    IN = 1 
    OUT = 2 
    state = OUT 
    w_cnt = 0 
    for c in s: 
        if state == OUT and not c.isspace(): 
            state = IN
            w_cnt += 1 
        elif state == IN and c.isspace(): 
            state = OUT 
    return w_cnt 


def main(): 
    s = input("Enter a string for word count:")
    nr_words = get_word_count(s)
    print(f"input string contains {nr_words} words")


main()