"""
@goal: 
    1) accept a string from end user 
    2) print the frequency of each unique character 
    version 1: You are allowed to use dict data type 
    version 2: w/o using dictionary data type
"""


def print_frequency_count_v1(s: str) -> None: 
    print("version 1:")
    if type(s) != str: 
        raise TypeError("s must be a string object")

    char_frequency = {} 
    for c in s: 
        count = char_frequency.setdefault(c, 0)
        char_frequency[c] = count + 1 

    for (char, frequency) in char_frequency.items(): 
        print(char, frequency, sep=':')

def print_frequency_count_v2(s: str) -> None: 
    print("version 2")
    if type(s) != str: 
        raise TypeError("s must be a string object")
    
    i = 0 
    while i < len(s): 
        j = 0 
        while j < i: 
            if s[j] == s[i]: 
                break
            j += 1   
        else: 
            freq_cnt = 0 
            k = i 
            while k < len(s): 
                if s[k] == s[i]: 
                    freq_cnt += 1 
                k += 1 
            print("Count(", s[i], "):", freq_cnt)
        i += 1               


def main(): 
    s = input("Enter a string for the frequency count:")
    print_frequency_count_v1(s) 
    print_frequency_count_v2(s) 

main()