"""
@author: Yogeshwar Shukla 
@date: 4th May 2024 
@goal: To implement and test the insertion sort algorithm 
"""

import sys 

def get_list(N: int) -> list[int]: 
    """
    @input: 
        @N: positive integer -> expected size of list 
    @output: 
        Populates newly created list with @N random numbers 
        stipulated between 0 to 1000 
    """
    from random import randint
    
    if type(N) != int: 
        raise TypeError("N must be an int")
    if N <= 0: 
        raise ValueError("N must be postivie ")

    L = []  
    
    starting_number = 0
    ending_number = 1001
    
    for i in range(N): 
        L.append(randint(starting_number, ending_number))
    
    return L 

def show_list(L: list[int], msg: str) -> None: 
    """
    @input: 
        @L: list of integers 
        @msg: string message
    @output: 
        Displays @msg along with @L on the standard output device 
    """
    print(msg)
    for i in range(len(L)): 
        print(f'L[{i}]:{L[i]}')

def insert_at_sorting_position(L: list[int], N: int) -> None: 
    """
    @input: 
        @L: non-empty list of integers 
        @N: length of list (not necessarily equal to len(L))
    @output: 
        None 
    @precondition: 
        1) N >= 2 
        2) L[0] to L[N-2] are sorted in non-decreasing order 
        3) Value of L[N-1] may be preventing from L[0] to L[N-1] 
            from being sorted
    @postcondition: 
        1) L[0] to L[N-1] is sorted  
    """
    if type(L) != list or type(N) != int: 
        raise TypeError("Bad type for input data")
    if N < 2: 
        raise ValueError("N must be greater than or equal to 2")
    key = L[N-1]
    i = N-2 
    while i > -1 and L[i] > key: 
        L[i+1] = L[i]
        i = i - 1 
    L[i+1] = key 

def insertion_sort(L: list[int]) -> None:
    """
    @input: 
        @L: L is a non-empty list of integers with no order 
    @output: 
        @L is sorted in place 
    """ 
    if type(L) != list: 
        raise TypeError("Bad input data")
    if len(L) == 0 or len(L) == 1: 
        return None 
    
    N = len(L)
    for i in range(2, N+1):
        insert_at_sorting_position(L, i) 

def main(): 
    N = int(input("Enter the size of the list:(greater than 2):"))
    if N < 2: 
        print("Bad size")
        sys.exit(-1)

    L = get_list(N)
    show_list(L, "Before sort:")
    insertion_sort(L)
    show_list(L, "After sort:")

main()