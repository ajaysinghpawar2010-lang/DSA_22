import sys 


def main(): 
    print("Hello, Python World")
    sys.exit(0)


main()