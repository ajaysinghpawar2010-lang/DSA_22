class node: 
    def __init__(self, data = 0): 
        self.data = data 
        self.prev = None 
        self.next = None 

N = node(100)
print(N.__dict__)

class node: 
    def __init__(self, data): 
        self.data = data 
        self.prev = None 
        self.next = None 

N = node(100)
print(N.__dict__)

class node: 
    def __init__(self, data): 
        self.data = data 
        self.prev = None 
        self.next = None 

N = node(100)
print(N.__dict__)


class node: 
    def __init__(self, data): 
        self.data = data 
        self.prev = None 
        self.next = None 

N = node(100)
print(N.__dict__)

class node: 
    def __init__(self, data): 
        self.data = data 
        self.prev = None 
        self.next = None 

N = node(100)
print(N.__dict__)


class cpa_list:
    @staticmethod
    def generic_insert(start: node, mid: node, end: node): 
        mid.next = end 
        mid.prev = start 
        start.next = mid 
        end.prev = mid 

    def __init__(self): 
        self.head_node = node(None)
        self.head_node.prev = self.head_node 
        self.head_node.next = self.head_node 

L = cpa_list() 

class hnode: 
    def __init__(self, v): 
        self.v = v 
        self.prev = None 
        self.next = None 

class hlist: 
    def __init__(self): 
        self.head_node = hnode(None)
        self.head_node.prev = self.head_node 
        self.head_node.next = self.head_node 

class vnode: 
    def __init__(self, v): 
        self.v = v 
        self.adj_list = hlist() 
        self.prev = None 
        self.next = None 

class vlist: 
    def __init__(self): 
        self.head_node = vnode(None)
        self.head_node.prev = self.head_node
        self.head_node.next = self.head_node 


class graph: 
    def __init__(self): 
        self.v_list = vlist() 
        self.nr_verices = 0 
        self.nr_eges = 0 