L1 = [10, 20, 5, 60, 90, 100]

max_element = L1[0]

i = 1
while i < len(L1):
    if L1[i] > max_element:
        max_element = L1[i]
    i = i + 1 

print("max in L1:", max_element) 

#-----------------------------------

L2 = [1000, 324, 500, 692, 10000] 

#----------------------------------

def find_max(L):
    max_element = L[0]
    i = 1
    while i < len(L):
        if L[i] > max_element:
            max_element = L[i]
        i = i + 1
    return max_element

X = find_max([10, 20, 30, 40])
find_max([10, 2030, 400, 1000])
