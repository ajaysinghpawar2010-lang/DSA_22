#include <iostream> 
#include <cstdlib> 
#include <stdexcept>

class array{
    private: 
        int* arr; 
        size_t N;

    public: 
        array(size_t _N) : arr(new int[_N]), N(_N){

        }

        ~array(){
            delete[] arr; 
        }

        int& operator[](size_t i){
            if(i < 0 || i >= N)
                throw std::out_of_range("Array index out of range"); 
            return *(arr + i); 
        }

        void merge(size_t p, size_t q, size_t r){
            int* a1 = 0; 
            int* a2 = 0; 
            size_t N1 = q - p + 1; 
            size_t N2 = r - q; 
            int i, j, k; 

            a1 = new int[N1];
            a2 = new int[N2]; 

            for(i = 0; i < N1; ++i)
                a1[i] = arr[p+i]; 

            for(i = 0; i < N1; ++i)
                a2[i] = arr[q+1+i]; 

            i = 0;
            j = 0;
            k = 0;

            while(true){
                if(a1[i] <= a2[j]){
                    arr[p+k] = a1[i]; 
                    k += 1; 
                    i += 1; 
                    if(i == N1){
                        while(j < N2){
                            arr[p+k] = a2[j];
                            k += 1;
                            j += 1; 
                        }
                        break; 
                    }
                }else{
                    arr[p+k] = a2[j]; 
                    k += 1; 
                    j += 1; 
                    if(j == N2){
                        while(i < N1){
                            arr[p+k] = a1[i]; 
                            k += 1; 
                            i += 1;
                        }
                        break; 
                    }
                }
            }

            delete[] a1; 
            a1 = 0; 

            delete[] a2; 
            a2 = 0; 
        }

        friend std::ostream& operator<<(std::ostream& os, const array& A); 
}; 

std::ostream& operator<<(std::ostream& os, const array& A){
    for(size_t i = 0; i < A.N; ++i)
        os << "A[" << i << "]:" << A.arr[i] << std::endl; 
    return os; 
}