def find_max(L: list[int]) -> int:
    '''
    @input:
    @L: Non-empty list of integers
    @return: max integer in L
    The function accepts a non-empty list of integers
    and returns the maximum integer in it.
    '''
    
    if type(L) != list:
        raise TypeError("L must a list object")
    if len(L) == 0:
        raise ValueError("L must be non empty")

    max_element = L[0]

    i = 1
    while i < len(L):
        if L[i] > max_element:
            max_element = L[i]
        i = i + 1

    return (max_element) 



