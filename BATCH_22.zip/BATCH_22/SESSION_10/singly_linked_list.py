"""
@author: Yogeshwar Shukla 
@date: 12th May 2024 
@goal: To implement & test singly linked list data structure 
"""

class Node: 
    def __init__(self, new_data: any): 
        self.data = new_data 
        self.next = None 

class SinglyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)

def main(): 
    L = SinglyLinkedList() 

    print("L.__dict__:", L.__dict__)
    print("L.head_node.__dict__:", L.head_node.__dict__)

main()