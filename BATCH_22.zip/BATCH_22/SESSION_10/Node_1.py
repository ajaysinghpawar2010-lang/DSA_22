class Node: 
    def __init__(self): 
        print("Inside Node.__init__()")
        print("Node.__init__():id(self):", id(self))

N = Node()
print("type(N):", type(N), "id(N):", id(N))

# id(N) and id(self) should be match with each other. 
print("N.__dict__:", N.__dict__)
