class Node: 
    def __init__(self, new_data): 
        self.data = new_data 
        self.prev = None 
        self.next = None 

N1 = Node(100)
N2 = Node(200)
N3 = Node(300)
N4 = Node(400)

print(N1.__dict__)
print(N2.__dict__)
print(N3.__dict__)
print(N4.__dict__)

N1.next = N2 
N2.prev = N1 

N2.next = N3 
N3.prev = N2 

N3.next = N4 
N4.prev = N3 

# N1.prev == None, N4.next == None 
print(N1.__dict__)
print(N2.__dict__)
print(N3.__dict__)
print(N4.__dict__)

run = N1 
while run is not None: 
    print(run.data)
    run = run.next 