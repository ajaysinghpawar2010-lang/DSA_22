class Node: 
    def __init__(self, new_data): 
        self.data = new_data 
        self.prev = None    # backward link 
        self.next = None    # forward link 

class DoublyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)
#---------------------------------------------------

class Node: 
    def __init__(self, new_data):
        self.data = new_data 
        self.prev = None 
        self.next = None 

class DoublyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)

#----

class Node: 
    def __init__(self, new_data): 
        self.data = new_data 
        self.prev = None 
        self.next = None 

class DoublyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)

#----------

class Node: 
    def __init__(self, new_data): 
        self.data = new_data 
        self.prev = None 
        self.next = None 

class DoublyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)

#-----------------

class Node: 
    def __init__(self, new_data): 
        self.data = new_data 
        self.prev = None 
        self.next = None 

class DoublyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None) 

#-----------------------