Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
D = {}
# D[new_key] = val # new_key:val is added
D['a'] = 10
D[1] = []
D
{'a': 10, 1: []}
D[1].append(3)
D
{'a': 10, 1: [3]}
D[1].append(5)
D[1].append(7)
D
{'a': 10, 1: [3, 5, 7]}
type(D)
<class 'dict'>
type(D[1])
<class 'list'>
D[1].remove(5)
D
{'a': 10, 1: [3, 7]}
# D[existing_key] = new_val
D
{'a': 10, 1: [3, 7]}
D['a'] = 100
D
{'a': 100, 1: [3, 7]}
# del D[existing_key]
D['a']
100
D
{'a': 100, 1: [3, 7]}
del D['a']
D
{1: [3, 7]}
L = []
L.append(10)
L
[10]
L.append(20)
L.append(30)
L.append(40)
T = (100, 200, 300, 400)
L
[10, 20, 30, 40]
L.append(T)
L
[10, 20, 30, 40, (100, 200, 300, 400)]
L.extend(T)
'
L
[10, 20, 30, 40, (100, 200, 300, 400), 100, 200, 300, 400]
L
[10, 20, 30, 40, (100, 200, 300, 400), 100, 200, 300, 400]
L
[10, 20, 30, 40, (100, 200, 300, 400), 100, 200, 300, 400]
L = [10, 20, 30, 40, 50]
L.insert(0, None)
L
[None, 10, 20, 30, 40, 50]
L.insert(len(L), None)
L
[None, 10, 20, 30, 40, 50, None]
# L.append(x) == L.insert(len(L), x)
L
[None, 10, 20, 30, 40, 50, None]
L.index(30)
3
L.insert(L.index(30), None)
L
[None, 10, 20, None, 30, 40, 50, None]
L.insert(L.index(30) + 1, None)
L
[None, 10, 20, None, 30, None, 40, 50, None]
#REMOVAL
# del L[index]
L = [10, 20, 30, 40, 50, 60]
del L[0]
L
[20, 30, 40, 50, 60]
del L[len()-1]
Traceback (most recent call last):
  File "<pyshell#54>", line 1, in <module>
    del L[len()-1]
TypeError: len() takes exactly one argument (0 given)
del L[len(L)-1]
L
[20, 30, 40, 50]
L
[20, 30, 40, 50]
L.remove(20)
L
[30, 40, 50]
L.remove(40)
L = [100, 20, 30, 40]
L
[100, 20, 30, 40]
ret = L.pop(1)
L
[100, 30, 40]
ret
20
L.pop()
40
L
[100, 30]
L
[100, 30]
L.clear()
C = """
L.append(x)
L.extend(container)
L.insert(index, object)
L.insert(0, object) # insert start
L.insert(len(L), object) # insert_end
L.insert(L.index(e), object) # insert object before e
L.insert(L.index(e) + 1, object) # insert object after e

del L[index]
L.remove(x)
ret = L.pop(index)
ret L.pop() == ret L.pop(len(L)-1)
"""
