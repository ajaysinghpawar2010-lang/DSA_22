OOP classical theory 

    Every memory block should be an object of some class defined in software 

    Each object must have following three properties: 
        1) identity 
        2) state 
        3) behaviour 

    Every OOP language must decide how to assign an 
    identity to an object? 

    