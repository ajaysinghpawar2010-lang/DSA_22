"""
@author: Yogeshwar Shukla 
@date: 18th May 2024 
@goal: To implement and test SinglyLinkedList 
"""

class Node: 
    def __init__(self, data: any):
        self.data = data 
        self.next = None 


class SinglyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)


    def insert_start(self, new_data: any) -> bool: 
        print(f"insert_start:id(self):{id(self)}, new_data:{new_data}")


    def insert_end(self, new_data: any) -> bool: 
        print(f"insert_end:id(self):{id(self)}, new_data:{new_data}")


    def insert_after(self, existing_data:  any, new_data: any) -> bool: 
        print(f'''insert_after:id(self):{id(self)}, 
                existing_data:{existing_data} 
                new_data:{new_data}''')


    def insert_before(self, existing_data: any, new_data: any) -> bool: 
         print(f'''insert_before:id(self):{id(self)}, 
                existing_data:{existing_data} 
                new_data:{new_data}''') 


L = SinglyLinkedList()
print(f"id(L):{id(L)}")
L.insert_start(100)
L.insert_start(200)
L.insert_end(300)
L.insert_end(400)
L.insert_after(100, 70)
L.insert_before(100, 60)