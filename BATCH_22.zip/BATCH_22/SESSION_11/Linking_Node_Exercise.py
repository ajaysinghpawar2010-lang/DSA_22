"""
@author: Yogeshwar Shukla 
@date: 18th May 2024 
@goal: Demonstration of linking node 
"""

class Node: 
    def __init__(self, new_data: any): 
        self.data = new_data 
        self.next = None 

class SinglyLinkedList: 
    def __init__(self): 
        self.head_node = Node(None)

def main(): 
    L = SinglyLinkedList() 

    print("L.__dict__:", L.__dict__)
    print("L.head_node.__dict__:", L.head_node.__dict__)

    N1 = Node(100)
    N2 = Node(200)

    N1.next = N2 

    print("id(N1):", hex(id(N1)))
    print("id(N2):", hex(id(N2)))

    print("N1.__dict__:", N1.__dict__) # {'data':100, 'next': addr of N2 in hex} 
    print("N2.__dict__:", N2.__dict__) # {'data':200, 'next':None}

main()