def geh(): 
    from sys import exc_info 
    exc_name, exc_data, _ = exc_info() 
    print(exc_name.__name__, exc_data, sep=':') 


class node: 
    def __init__(self, data): 
        self.data = data 
        self.prev = None 
        self.next = None 
     

class List: 
    @staticmethod 
    def generic_insert(start: node, mid: node, end: node): 
        mid.next = end 
        mid.prev = start 
        start.next = mid 
        end.prev = mid 


    def __init__(self, cls: type):
        if type(cls) != type: 
            raise TypeError('cls must be a class')
        self.data_type = cls  
        self.head_node = node(None)
        self.head_node.prev = self.head_node 
        self.head_node.next = self.head_node 


    def insert_end(self, data): 
        if type(data) != self.data_type: 
            raise TypeError(f"data must of {self.data_type.__name__}")
        List.generic_insert(self.head_node.prev, node(data), self.head_node)


L1 = List(int)
L2 = List(float)


try: 
    L1.insert_end(1.1)
except: 
    geh() 


try: 
    L2.insert_end(400)
except: 
    geh() 
    