#include "bst.hpp"

int main(void){
    bst* p_bst = 0; 

    p_bst = new bst; 
    p_bst->insert(100); 

    delete p_bst; 
    p_bst = 0; 

    return 0; 
}