#include "bst.hpp"

bst_node::bst_node(int new_data) : data(new_data), left(0), right(0), parent(0){

}

bst::bst() : root_node(0), nr_elements(0){

}

bst::~bst(){
    
}

void bst::insert(int new_data){
    bst_node* p_new_node = 0; 
    bst_node* run = 0; 

    p_new_node = new bst_node(new_data); 
    if(this->root_node == 0){
        this->root_node = p_new_node; 
        this->nr_elements += 1; 
        return; 
    }

    run = this->root_node; 
    while(true){
        if(new_data <= run->data){
            if(run->left == 0){
                run->left = p_new_node;
                run->left->parent = run; 
                break; 
            }
            else{
                run = run->left; 
            }
        }else{
            if(run->right == 0){
                run->right = p_new_node; 
                run->right->parent = run; 
                break; 
            }else{
                run = run->right; 
            }
        }
    }

    this->nr_elements += 1; 
}

