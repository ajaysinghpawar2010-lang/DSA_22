#ifndef _BST_HPP
#define _BST_HPP 

class bst_node{
    friend class bst; 
    private: 
        int data; 
        bst_node* left; 
        bst_node* right; 
        bst_node* parent; 
        bst_node(int new_data); 
}; 

class bst{
    private: 
        bst_node* root_node; 
        unsigned int nr_elements; 
        bst(); 
        ~bst(); 
}; 


#endif 