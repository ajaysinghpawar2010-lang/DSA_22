'''
@author: Yogeshwar
@goal: to implement ADT of bst
''' 

class bst_node: 
    def __init__(self, data: any): 
        self.data = data 
        self.left = None 
        self.right = None 
        self.parent = None 
    

class bst: 


    def __init__(self): 
        self.root_node = None 
        self.nr_elements = 0 


    def insert(self, new_data: any) -> None: 
        new_node = bst_node(new_data)
        if self.root_node == None:
            self.root_node = new_node 
            self.nr_elements += 1 
            return None 
        run = self.root_node 
        while True: 
            if new_data <= run.data: 
                if run.left == None: 
                    run.left = new_node 
                    run.left.parent = run 
                    break 
                else: 
                    run = run.left 
            else: 
                if run.right == None: 
                    run.right = new_node 
                    run.right.parent = run 
                    break 
                else: 
                    run = run.right 
        self.nr_elements += 1 
        

def main(): 
    T = bst() 
    print("T.root_node:", T.root_node)
    print("T.nr_elements:", T.nr_elements)
    
    test_node = bst_node(100)
    print(
            f'''test_node.data:{test_node.data}, 
            test_node.left:{test_node.left}, 
            test_node.right:{test_node.right}, 
            test_node.parent:{test_node.parent}'''
        )

main()